﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-21
 * Updated: 2022-7-21
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents a VehicleDataForm class.
    /// </summary>
    public partial class VehicleDataForm : Form
    {
        private OleDbConnection connection;
        private OleDbDataAdapter adapter; 
        private OleDbCommand command;   
        private DataSet dataset;
        private BindingSource bindingSource;
        private OleDbCommandBuilder oleDbCommandBuilder;

        /// <summary>
        /// Initializes an instance of VehicleDataForm.
        /// </summary>
        public VehicleDataForm()
        {
            InitializeComponent();

            this.Load += VehicleDataForm_Load;
            this.mnuFileClose.Click += MnuFileClose_Click;
            this.mnuFileSave.Click += MnuFileSave_Click;
            this.dgvVehicleData.RowHeaderMouseClick += DgvVehicleData_RowHeaderMouseClick;
            this.dgvVehicleData.SelectionChanged += DgvVehicleData_SelectionChanged;
            this.dgvVehicleData.CellValueChanged += DgvVehicleData_CellValueChanged;
            this.mnuEditDelete.Click += MnuEditDelete_Click;
            this.FormClosing += VehicleDataForm_FormClosing;
            
        }

        /// <summary>
        /// Handles the FormClosing event of this form.
        /// </summary>
        private void VehicleDataForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            string message = "Do you wish to save the changes?";
            string caption = "Save";
            MessageBoxButtons buttons = MessageBoxButtons.YesNoCancel;
            MessageBoxIcon icon = MessageBoxIcon.Error;
            MessageBoxDefaultButton defaultButton2 = MessageBoxDefaultButton.Button3;
            DialogResult result = MessageBox.Show(message, caption, buttons, icon, defaultButton2);

            if (result == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
            else if(result == DialogResult.No)
            {
                e.Cancel= false;
            }
            else if(result == DialogResult.Yes)
            {
                InputValidation();

                try
                {
                    this.adapter.RowUpdated += new OleDbRowUpdatedEventHandler(Adapter_RowUpdated);
                    adapter.Update(dataset, "VehicleStock");
                    dgvVehicleData.EndEdit();
                }
                catch (InvalidOperationException)
                {
                    string errorMessage = "An error occurred while saving the changes. Do you still wish to close this window?";
                    string errorCaption = "Save Error";
                    MessageBoxButtons errorButton = MessageBoxButtons.YesNo;
                    MessageBoxIcon errorIcon = MessageBoxIcon.Error;
                    MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
                    DialogResult errorResult = MessageBox.Show(errorMessage, errorCaption, errorButton, errorIcon, defaultButton);

                    if (errorResult == DialogResult.Yes)
                    {
                        e.Cancel = false;
                    }
                    else if(errorResult == DialogResult.No)
                    {
                        e.Cancel= true;
                    }
                }

            }

        }

        /// <summary>
        /// Handles the Click event of Delete menu item.
        /// </summary>
        private void MnuEditDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = new DataGridViewRow();
                row = this.dgvVehicleData.CurrentRow;
                DataGridViewCellCollection cells = row.Cells;
                DataGridViewCell stockItem = cells[1];

                string message = $"Are you sure you want to permanently delete stock item {stockItem.Value}?";
                string caption = "Delete Stock Item";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Exclamation;
                MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(message, caption, buttons, icon, defaultButton);

                if (result == DialogResult.Yes)
                {
                    this.dgvVehicleData.Rows.Remove(row);
                    adapter.Update(dataset, "VehicleStock");
                    this.mnuEditDelete.Enabled = false;
                }

            }
            catch (ArgumentOutOfRangeException)
            {
                string errorMessage = "An error occurred while deleting the selected vehicle.";
                string errorCaption = "Deletion Error";
                MessageBoxButtons errorButton = MessageBoxButtons.OK;
                MessageBoxIcon errorIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton2 = MessageBoxDefaultButton.Button2;
                MessageBox.Show(errorMessage, errorCaption, errorButton, errorIcon, defaultButton2);
            }

        }

        /// <summary>
        /// Handles the RowUpdated event of this Adapter.
        /// </summary>
        private void Adapter_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            if (e.StatementType == StatementType.Insert)
            {
                OleDbCommand command = new OleDbCommand("Select @@IDENTITY", connection);
                e.Row["ID"] = (int)command.ExecuteScalar();
            }
        }

        /// <summary>
        /// Handles the SelectionChanged event of DataGridView control. 
        /// </summary>
        private void DgvVehicleData_SelectionChanged(object sender, EventArgs e)
        {
            this.mnuEditDelete.Enabled = false;

            if (this.dgvVehicleData.CurrentRow != null && this.dgvVehicleData.CurrentRow.IsNewRow)
            {
                DataGridViewRow row = new DataGridViewRow();
                row = this.dgvVehicleData.CurrentRow;
                DataGridViewCellCollection cells = row.Cells;
                DataGridViewCell soldby = cells[9];
                soldby.Value = "0";
                
            }
        }

        /// <summary>
        /// Handles the RowHeaderMouseClick event of DataGridView control. 
        /// </summary>
        private void DgvVehicleData_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(!this.dgvVehicleData.CurrentRow.IsNewRow)
            this.mnuEditDelete.Enabled = true;
        }

        /// <summary>
        /// Handles the Click event of Save menu item.
        /// </summary>
        private void MnuFileSave_Click(object sender, EventArgs e)
        {
            InputValidation();

            try
            {
                oleDbCommandBuilder = new OleDbCommandBuilder();
                oleDbCommandBuilder.ConflictOption = ConflictOption.OverwriteChanges;

                this.adapter.RowUpdated += new OleDbRowUpdatedEventHandler(Adapter_RowUpdated);
                adapter.Update(dataset, "VehicleStock");
                dgvVehicleData.EndEdit();
            }
            catch (DBConcurrencyException)
            {
                string errorMessage = "An error occurred while saving the changes to the vehicle data.";
                string errorCaption = "Save Error";
                MessageBoxButtons errorButton = MessageBoxButtons.OK;
                MessageBoxIcon errorIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton2 = MessageBoxDefaultButton.Button2;
                MessageBox.Show(errorMessage, errorCaption, errorButton, errorIcon, defaultButton2);
            }

            this.Text = "Vehicle Data";
            this.mnuFileSave.Enabled = false;
        }

        /// <summary>
        /// Handles the Load event of this form.
        /// </summary>
        private void VehicleDataForm_Load(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='AMDatabase.mdb'";
            connection = new OleDbConnection();
            connection.ConnectionString = connectionString;

            try
            {
                connection.Open();
            }
            catch(OleDbException)
            {
                string message = "Unable to load vehicle data.";
                string caption = "Data Load Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Error;
                MessageBox.Show(message, caption, buttons, icon);
            }
            
            command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "Select * from VehicleStock";

            adapter = new OleDbDataAdapter();
            adapter.SelectCommand = command;
            dataset = new DataSet();

            adapter.Fill(dataset, "VehicleStock");

            bindingSource = new BindingSource();    
            bindingSource.DataSource = dataset.Tables["VehicleStock"];
            dgvVehicleData.DataSource = bindingSource;


            dgvVehicleData.Columns["ID"].Visible = false;
            dgvVehicleData.Columns["SoldBy"].Visible = false;

            oleDbCommandBuilder = new OleDbCommandBuilder();
            oleDbCommandBuilder.ConflictOption = ConflictOption.OverwriteChanges;

            oleDbCommandBuilder.DataAdapter = adapter;

            adapter.InsertCommand = oleDbCommandBuilder.GetInsertCommand();
            adapter.UpdateCommand = oleDbCommandBuilder.GetUpdateCommand();
            adapter.DeleteCommand = oleDbCommandBuilder.GetDeleteCommand();            

        }

        /// <summary>
        /// Handles the CellValueChanged event of DataGridView control.
        /// </summary>
        private void DgvVehicleData_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            this.Text = "* Vehicle Data";
            this.mnuFileSave.Enabled = true;  
        }

        /// <summary>
        /// Handles the Click event of Close menu item.
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.FormClosing -= VehicleDataForm_FormClosing;

            if(this.dataset.HasChanges())
            { 
                string message ="Do you want to save the changes.";
                string caption = "Reminder";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                MessageBoxIcon icon = MessageBoxIcon.Exclamation;
                DialogResult result = MessageBox.Show(message, caption, buttons, icon);
                if (result == DialogResult.Yes)
                {
                    this.adapter.RowUpdated += new OleDbRowUpdatedEventHandler(Adapter_RowUpdated);
                    adapter.Update(dataset, "VehicleStock");
                    dgvVehicleData.EndEdit();
                }
            }
            
            bindingSource.EndEdit();
            bindingSource.Dispose();
            connection.Close();
            connection.Dispose();
            this.Close();
        }

        /// <summary>
        /// Validate the modification to the DataGridView.
        /// </summary>
        private void InputValidation()
        {
            try
            {
                DataRowCollection rows = dataset.Tables["VehicleStock"].Rows;

                foreach (DataRow row in rows)
                {
                    object[] items = row.ItemArray;

                    string stockNumber = items[1].ToString();
                    int year = Convert.ToInt32(items[2]);
                    string make = items[3].ToString();
                    string model = items[4].ToString();
                    int mile = Convert.ToInt32(items[5]);
                    bool automatic = (bool)items[6];
                    string color = items[7].ToString();
                    decimal price = Convert.ToDecimal(items[8]);
                    int soldby = Convert.ToInt32(items[9]);

                    if (stockNumber.Equals(String.Empty))
                    {
                        throw new ArgumentException("The StockID can not be blank");
                    }

                    if (year > 9999 || year < 1885)
                    {
                        throw new ArgumentOutOfRangeException("ManufacturerYear", "The ManufacturerYear can not be less than 1885 or greater than 9999");
                    }

                    if (make.Equals(String.Empty))
                    {
                        throw new ArgumentException("The Make can not be blank");

                    }

                    if (model.Equals(String.Empty))
                    {
                        throw new ArgumentException("The Model can not be blank");
                    }

                    if (mile < 0)
                    {
                        throw new ArgumentOutOfRangeException("Mileage","The Mileage can not be less than zero");
                    }

                    if (color.Equals(String.Empty))
                    {
                        throw new ArgumentException("The Color can not be blank");
                    }

                    if (price < 0)
                    {
                        throw new ArgumentOutOfRangeException("BasePrice","The BasePrice can not be less than zero");
                    }

                }
            }
            catch (ArgumentOutOfRangeException exception)
            {
                string errorMessage = exception.Message;
                string errorCaption = "Input Error";
                MessageBoxButtons errorButton = MessageBoxButtons.OK;
                MessageBoxIcon errorIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton2 = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(errorMessage, errorCaption, errorButton, errorIcon, defaultButton2);
                if (result == DialogResult.OK)
                {
                    this.dataset.Tables["VehicleStock"].RejectChanges();
                }
            }
            catch (ArgumentException exception)
            {
                string errorMessage = exception.Message;
                string errorCaption = "Input Error";
                MessageBoxButtons errorButton = MessageBoxButtons.OK;
                MessageBoxIcon errorIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton2 = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(errorMessage, errorCaption, errorButton, errorIcon, defaultButton2);
                if (result == DialogResult.OK)
                {
                    this.dataset.Tables["VehicleStock"].RejectChanges();
                }
            }
            catch(InvalidCastException)
            {
                string errorMessage = "The input data is incomplete or invalid";
                string errorCaption = "Input Error";
                MessageBoxButtons errorButton = MessageBoxButtons.OK;
                MessageBoxIcon errorIcon = MessageBoxIcon.Error;
                MessageBoxDefaultButton defaultButton2 = MessageBoxDefaultButton.Button2;
                DialogResult result = MessageBox.Show(errorMessage, errorCaption, errorButton, errorIcon, defaultButton2);
                if (result == DialogResult.OK)
                {
                    this.dataset.Tables["VehicleStock"].RejectChanges();
                }
            }
        }
    }
}
