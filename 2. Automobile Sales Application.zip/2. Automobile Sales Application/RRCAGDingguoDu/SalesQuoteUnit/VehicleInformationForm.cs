﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-13
 * Updated: 2022-7-13
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RRCAG.Data;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents a VehicleInformationForm class.
    /// </summary>
    public partial class VehicleInformationForm : Form
    {
        /// <summary>
        /// Initializes an instance of VehicleInformationForm Form.
        /// </summary>
        /// <param name="vehicle">The vehicle instance of combo box selected item from SalesQuote class </param>
        public VehicleInformationForm(Vehicle vehicle)
        {
            InitializeComponent();

            this.Text = String.Format("{0}-{1}{2}{3}",vehicle.StockID,vehicle.ManufacturedYear,
                                                            vehicle.Manufacturer,vehicle.Model);

            this.lblStockID.Text = vehicle.StockID;
            this.lblYear.Text = vehicle.ManufacturedYear.ToString();
            this.lblManufacturer.Text = vehicle.Manufacturer.ToString();    
            this.lblModel.Text = vehicle.Model.ToString();
            this.lblTransmission.Text = String.Format("{0}",vehicle.IsAutomatic ? "Automatic" : "Manual");
            this.lblMileage.Text = string.Format("{0:N0}",vehicle.Mileage);
            this.lblColor.Text = vehicle.Colour.ToString();
            this.lblBasePrice.Text = String.Format("{0:C}",vehicle.BasePrice);

            this.btnClose.Click += BtnClose_Click;

        }

        /// <summary>
        /// Handles the Click event of the close button.
        /// </summary>
        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
