﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-3
 * Updated: 2022-7-23
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Du.Dingguo.Business;
using System.Windows;
using RRCAG.Data;
using System.Data.OleDb;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents a SalesQuoteForm class.
    /// </summary>
    public partial class SalesQuoteForm : Form
    {
        private decimal vehicelPrice;
        private decimal tradeValue;
        private decimal salesTaxRate;
        SalesQuote salesQuote;
        private Accessories accessoriesChosen;
        private ExteriorFinish exteriorFinishChosen;
        private int numberOfYears;
        private decimal annualInterestRate;

        private OleDbCommand command;
        private OleDbDataAdapter adapter;
        private OleDbConnection connection;
        private DataSet dataSet;
        private BindingList<Vehicle> vehiclesList;
   
        /// <summary>
        /// Initializes an instance of SalesQuote Form.
        /// </summary>
        public SalesQuoteForm()
        {
            InitializeComponent();


            RetriveDate();

            BindingSource bindingSource = new BindingSource();
            bindingSource.DataSource = vehiclesList;
            cboVehicleSalePrice.DataSource = bindingSource;

            cboVehicleSalePrice.DisplayMember = "stockID";

            cboVehicleSalePrice.SelectedItem = null;

            mnuViewVehicelInfo.Enabled = false;

            this.mnuViewVehicelInfo.Click += MnuViewVehicelInfo_Click;

            this.cboVehicleSalePrice.SelectedIndexChanged += CboVehicleSalePrice_SelectedIndexChanged;

            this.btnCalculateQuote.Click += BtnCalculateQuote_Click;

            this.chkComputerNavigation.Click += Recaculate_Changed;

            this.chkLeatherInterior.Click += Recaculate_Changed;

            this.chkStereoSystem.Click += Recaculate_Changed;

            this.radStandard.Click += Recaculate_Changed;

            this.radPearlizd.Click += Recaculate_Changed;

            this.radCustomizedDetailing.Click += Recaculate_Changed;

            this.nudYears.ValueChanged += Recaculate_Changed;

            this.nudRate.ValueChanged += Recaculate_Changed;

            this.cboVehicleSalePrice.SelectedIndexChanged += Index_IndexChanged;

            this.txtTradeValue.TextChanged += Index_IndexChanged;

            this.btnReset.Click += BtnReset_Click;

            this.mnuFileClose.Click += MnuFileClose_Click;


        }

        /// <summary>
        /// Retrieve data from database. 
        /// </summary>
        private void RetriveDate()
        {
            
            connection = new OleDbConnection();
            String connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='AMDatabase.mdb'";
            connection.ConnectionString = connectionString;

            try
            {
                connection.Open();
            }
            catch (OleDbException)
            {
                string message = "Unable to load vehicle data.";
                string caption = "Data Load Error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Error;
                MessageBox.Show(message, caption, buttons, icon);
            }

            command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "Select * from VehicleStock";

            adapter = new OleDbDataAdapter();
            adapter.SelectCommand = command;

            dataSet = new DataSet();
            int rowNumber = adapter.Fill(dataSet, "VehicleStock");

            if(rowNumber == 0)
            {
                string message = "There are no vehicles in stock.";
                string caption = "Sales Quote Data";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Information;
                DialogResult result = MessageBox.Show(message, caption, buttons, icon);
                if(result == DialogResult.OK)
                {
                    this.Close();
                }    
            }

            DataRowCollection rows = dataSet.Tables["VehicleStock"].Rows;
            vehiclesList = new BindingList<Vehicle>();

            foreach (DataRow row in rows)
            {
                object[] items = row.ItemArray;

                string stockNumber = items[1].ToString();
                int year = Convert.ToInt32(items[2]);
                string make = items[3].ToString();
                string model = items[4].ToString();
                int mile = Convert.ToInt32(items[5]);
                bool automatic = (bool)items[6];
                string color = items[7].ToString();
                decimal price = Convert.ToDecimal(items[8]);
                int soldby = Convert.ToInt32(items[9]);

                if (soldby == 0)
                {
                    Vehicle vehicle = new Vehicle(stockNumber, year, make, model, mile, automatic, color, price);
                    vehiclesList.Add(vehicle);
                }
            }
        }

       

        /// <summary>
        /// Handles the Click event of the vehicle information menu item.
        /// </summary>
        private void MnuViewVehicelInfo_Click(object sender, EventArgs e)
        {
            Vehicle vehicle = (Vehicle)this.cboVehicleSalePrice.SelectedItem;
            VehicleInformationForm vehicleInformationForm = new VehicleInformationForm(vehicle);
            vehicleInformationForm.ShowDialog();    
        }

        /// <summary>
        /// Handles the Enable event of the vehicle information menu item.
        /// </summary>
        private void CboVehicleSalePrice_SelectedIndexChanged(object sender, EventArgs e)
        {
           this.mnuViewVehicelInfo.Enabled = this.cboVehicleSalePrice.SelectedItem != null;
        }

        /// <summary>
        ///  Handles the Click event of the close menu item.
        /// </summary>
        private void MnuFileClose_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        /// <summary>
        /// Handles the Click event of the reset button.
        /// </summary>
        private void BtnReset_Click(object sender, EventArgs e)
        {
            string message = "Do you want to reset the form?";
            string caption = "Reset Form";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            MessageBoxIcon boxIcon = MessageBoxIcon.Warning;
            MessageBoxDefaultButton defaultButton = MessageBoxDefaultButton.Button2;
            DialogResult result = MessageBox.Show(message, caption, buttons, boxIcon, defaultButton);

            if(result == DialogResult.Yes)
            {
                salesQuote = null;

                this.errorProvider.SetError(this.cboVehicleSalePrice, String.Empty);

                this.errorProvider.SetError(this.txtTradeValue, String.Empty);

                InputInitialize();

                OutputInitialize();
            }

        }

        /// <summary>
        /// Handles the ValueChanged event when the index of the vehicle combo box or text of trade-in value changes.
        /// </summary>
        private void Index_IndexChanged(object sender, EventArgs e)
        {
            OutputInitialize(); 
        }

        /// <summary>
        /// Handles the Click event or the ValueChanged event When an accessory
        /// or exterior finish is selected after first caculation or When the
        /// value of years or annual interest rate is changed.
        /// </summary>
        private void Recaculate_Changed(object sender, EventArgs e)
        {
            if (salesQuote != null)
                BtnCalculateQuote_Click(sender, e);
        }

        /// <summary>
        /// Handles the Click event of the calculate quote button.
        /// </summary>
        private void BtnCalculateQuote_Click(object sender, EventArgs e)
        {
            tradeValue = 0;

            this.errorProvider.SetError(this.cboVehicleSalePrice,String.Empty);
            this.errorProvider.SetError(this.txtTradeValue,String.Empty);

            InputValidation();

            salesTaxRate = 0.13M;

            InputSelection();    

            if (errorProvider.GetError(this.cboVehicleSalePrice).Equals(string.Empty) 
                && errorProvider.GetError(this.txtTradeValue).Equals(string.Empty))
            {
                Vehicle vehicle = (Vehicle)this.cboVehicleSalePrice.SelectedItem;
                vehicelPrice = vehicle.BasePrice;
                salesQuote = new SalesQuote(vehicelPrice, tradeValue, salesTaxRate,
                accessoriesChosen, exteriorFinishChosen);

                OutputFormat();
            }
            else 
            {
                OutputInitialize();
            }

        }
        /// <summary>
        /// Initialize the output of Summary and Finance section to empty. 
        /// </summary>
        private void OutputInitialize()
        {
            this.lblVehicleSalePrice.Text = string.Empty;

            this.lblOptions.Text = string.Empty;

            this.lblSubtotal.Text = string.Empty;

            this.lblSalesTax.Text = string.Empty;

            this.lblTotal.Text = string.Empty;

            this.lblTradeIn.Text = string.Empty;

            this.lblAmountDue.Text = string.Empty;

            this.lblMonthlyPayment.Text = string.Empty;
        }

        /// <summary>
        /// Initialize the input setting for quote calculation. 
        /// </summary>
        private void InputInitialize()
        {
            this.cboVehicleSalePrice.SelectedItem = null;

            this.txtTradeValue.Text = "0";

            this.chkComputerNavigation.Checked = false;

            this.chkLeatherInterior.Checked = false;

            this.chkStereoSystem.Checked = false;

            this.radStandard.Checked = true;

            this.radPearlizd.Checked = false;

            this.radCustomizedDetailing.Checked = false;

            this.nudYears.Value = 1;

            this.nudRate.Value = 5;
        }

        /// <summary>
        /// Format the output of the calculation result.
        /// </summary>
        private void OutputFormat()
        {
            this.lblVehicleSalePrice.Text = string.Format("{0:C}", vehicelPrice);

            this.lblOptions.Text = (salesQuote.AccessoryCost + salesQuote.FinishCost).ToString();

            this.lblSubtotal.Text = string.Format("{0:C}", salesQuote.SubTotal);

            this.lblSalesTax.Text = salesQuote.SalesTax.ToString();

            this.lblTotal.Text = string.Format("{0:C}", salesQuote.Total);

            this.lblTradeIn.Text = "-" + this.txtTradeValue.Text;

            this.lblAmountDue.Text = string.Format("{0:C}", salesQuote.AmountDue);

            numberOfYears = (int)this.nudYears.Value * 12;

            annualInterestRate = this.nudRate.Value / 100;

            this.lblMonthlyPayment.Text = String.Format("{0:C}", Financial.GetPayment(annualInterestRate / 12, numberOfYears,
                salesQuote.AmountDue));
        }

        /// <summary>
        /// Validate the input of SalePrice and TradeValue.
        /// </summary>
        private void InputValidation()
        {
            try
            {
                if (cboVehicleSalePrice.SelectedItem == null)
                {
                    throw new ArgumentOutOfRangeException("input");
                }
                Vehicle vehicle = (Vehicle)this.cboVehicleSalePrice.SelectedItem;
                vehicelPrice = vehicle.BasePrice;

            }
            catch (ArgumentOutOfRangeException)
            {
                this.errorProvider.SetError(this.cboVehicleSalePrice,
                    "A vehicle must be selected.");
                this.errorProvider.SetIconPadding(this.cboVehicleSalePrice, 3);
            }

            try
            {
                if (Int32.Parse(this.txtTradeValue.Text) < 0)
                {
                    throw new ArgumentOutOfRangeException("input");
                }

                if (vehicelPrice < Int32.Parse(this.txtTradeValue.Text) && this.cboVehicleSalePrice.SelectedItem != null)
                {
                    throw new ArgumentException("input");
                }

                tradeValue = Int32.Parse(this.txtTradeValue.Text);
            }
            catch (FormatException)
            {
                if (this.txtTradeValue.Text == "")
                {
                    this.errorProvider.SetError(this.txtTradeValue,
                    "Trade-in value is a required field.");
                    this.errorProvider.SetIconPadding(this.txtTradeValue, 3);
                }
                else
                {
                    this.errorProvider.SetError(this.txtTradeValue,
                    "Trade-in value cannot contain letters or special characters.");
                    this.errorProvider.SetIconPadding(this.txtTradeValue, 3);
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                this.errorProvider.SetError(this.txtTradeValue,
                    "Trade-in value cannot be less than 0.");
                this.errorProvider.SetIconPadding(this.txtTradeValue, 3);
            }
            catch (ArgumentException)
            {
                this.errorProvider.SetError(this.txtTradeValue,
                    "Trade-in value cannot exceed the vehicle sale price.");
                this.errorProvider.SetIconPadding(this.txtTradeValue, 3);
            }
        }

        /// <summary>
        /// Select the accessories and exterior finish.
        /// </summary>
        private void InputSelection()
        {
            if (this.chkStereoSystem.Checked && !this.chkLeatherInterior.Checked && !this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.StereoSystem;
            }
            else if (this.chkLeatherInterior.Checked && !this.chkStereoSystem.Checked && !this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.LeatherInterior;
            }
            else if (this.chkComputerNavigation.Checked && !this.chkLeatherInterior.Checked && !this.chkStereoSystem.Checked)
            {
                accessoriesChosen = Accessories.ComputerNavigation;
            }
            else if (this.chkStereoSystem.Checked && this.chkLeatherInterior.Checked && !this.chkComputerNavigation.Checked)
            {
                accessoriesChosen = Accessories.StereoAndLeather;
            }
            else if (this.chkStereoSystem.Checked && this.chkComputerNavigation.Checked && !this.chkLeatherInterior.Checked)
            {
                accessoriesChosen = Accessories.StereoAndNavigation;
            }
            else if (this.chkLeatherInterior.Checked && this.chkComputerNavigation.Checked && !this.chkStereoSystem.Checked)
            {
                accessoriesChosen = Accessories.LeatherAndNavigation;
            }
            else if (this.chkComputerNavigation.Checked && this.chkLeatherInterior.Checked && this.chkStereoSystem.Checked)
            {
                accessoriesChosen = Accessories.All;
            }
            else
            {
                accessoriesChosen = Accessories.None;
            }

            if (this.radStandard.Checked)
            {
                exteriorFinishChosen = ExteriorFinish.Standard;
            }
            else if (this.radPearlizd.Checked)
            {
                exteriorFinishChosen = ExteriorFinish.Pearlized;

            }
            else if (this.radCustomizedDetailing.Checked)
            {
                exteriorFinishChosen = ExteriorFinish.Custom;
            }
            else
            {
                exteriorFinishChosen = ExteriorFinish.None;
            }
        }
    }
}
