﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RRCAGDingguoDu
{
    public partial class LauncherForm : Form
    {
        public LauncherForm()
        {
            InitializeComponent();

            this.mnuFileOpenSalesQuote.Click += MnuFileOpenSalesQuote_Click;

            this.mnuFileOpenCarWash.Click += MnuFileOpenCarWash_Click;

            this.mnuHelpAbout.Click += MnuHelpAbout_Click;

            this.mnuFileExit.Click += MnuFileExit_Click;

            this.mnuDataVehicle.Click += MnuDataVehicle_Click;
        }

        private void MnuDataVehicle_Click(object sender, EventArgs e)
        {
            VehicleDataForm vehicleDataForm = new VehicleDataForm();
            vehicleDataForm.ShowDialog();
        }

        private void MnuFileOpenCarWash_Click(object sender, EventArgs e)
        {
            CarWashForm carWashForm = new CarWashForm();
            carWashForm.ShowDialog();
        }

        private void MnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void MnuHelpAbout_Click(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }

        private void MnuFileOpenSalesQuote_Click(object sender, EventArgs e)
        {
            SalesQuoteForm salesQuoteForm = new SalesQuoteForm();

            if(!salesQuoteForm.IsDisposed)
            {
                salesQuoteForm.ShowDialog();
            }
            
        }
    }
}
