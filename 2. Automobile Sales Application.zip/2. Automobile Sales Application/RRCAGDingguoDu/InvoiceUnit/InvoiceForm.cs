﻿/*
 * Name: Dingguo Du
 * Program: Business Information Technology
 * Course: ADEV-2008 Programming 2
 * Created: 2022-7-13
 * Updated: 2022-7-13
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RRCAGDingguoDu
{
    /// <summary>
    /// Represents a invoice base class.
    /// </summary>
    public partial class InvoiceForm : Form
    {
        public InvoiceForm()
        {
            InitializeComponent();

            label1.Text = "RRC Automotive Group";
            label2.Text = "777 Inheritance Drive";
            label3.Text = "Winnipeg,Manitoba,I0I0I0";
            label4.Text = "204-867-5309";

        }

       
    }
}
