﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class UserInfoBLL
    {
        UserInfoDAL userInfoDAL = new UserInfoDAL();

        public bool IsLoginByLoginName(string loginName, string pwd, out string msg)
        {
            bool flag = false;
            UserInfo userInfo = userInfoDAL.IsLoginByLoginName(loginName);//获取对象
            if(userInfo !=null)
            {
               if(pwd == userInfo.Pwd)
               {
                    msg = "登录成功";
                    flag = true;
               }
               else
                {
                    msg = "密码错误";
                }
            }
            else
            {
                msg = "账号不存在";
            }
               
            return flag;
            
        }
    }
}
