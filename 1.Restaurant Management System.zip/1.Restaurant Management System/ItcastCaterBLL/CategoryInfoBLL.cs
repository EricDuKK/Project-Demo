﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class CategoryInfoBLL
    {
        CategoryInfoDAL dal = new CategoryInfoDAL();


        /// <summary>
        /// 根据商品类别的id删除该类别
        /// </summary>
        /// <param name="catId"></param>
        /// <returns></returns>
        public bool SoftDelelteCategoryInfoByCatId(int catId)
        {
            return dal.SoftDelelteCategoryInfoByCatId(catId) > 0;
        }

        /// <summary>
        /// 新增或修改商品类别
        /// </summary>
        /// <param name="ct">类别对象</param>
        /// <param name="temp">1----新增,2----修改</param>
        /// <returns></returns>
        public bool SaveCategoryInfo(CategoryInfo ct, int temp)
        {
            int r = -1;
            if (temp == 1)//新增
            {
                r = dal.AddCategoryInfo(ct);
            }
            else if (temp == 2)//修改
            {
                r = dal.UpdateCategory(ct);
            }
            return r > 0;
        }

        /// <summary>
        /// 根据类别的id查询类别对象
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CategoryInfo GetCategoryInfoById(int id)
        {
            return dal.GetCategoryInfoById(id);
        }


            /// <summary>
            /// 查询所有的商品类别
            /// </summary>
            /// <param name="delFlag"></param>
            /// <returns></returns>
            public List<CategoryInfo> GetAllCategoryInfoByDelFlag(int delFlag)
        {
            return dal.GetAllCategoryInfoByDelFlag(delFlag);
        }
    }
}
