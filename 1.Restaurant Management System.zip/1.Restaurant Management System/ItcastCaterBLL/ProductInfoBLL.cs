﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class ProductInfoBLL
    {
        ProductInfoDAL dal = new ProductInfoDAL();


        /// <summary>
        /// 根据拼音或者编号查询产品
        /// </summary>
        /// <param name="num">可以是拼音，可以是编号</param>
        /// <param name="temp">1---拼音，2---编号</param>
        /// <returns></returns>
        public List<ProductInfo> GetProductInfoBySpellOrNum(string num, int temp)
        {
           return  dal.GetProductInfoBySpellOrNum(num, temp);
        }

            /// <summary>
            /// 根据商品类别的id查询该类别下有没有产品
            /// </summary>
            /// <param name="catId"></param>
            /// <returns></returns>
            public int GetProductInfoCountByCatId(int catId)
        {
            return Convert.ToInt32(dal.GetProductInfoCountByCatId(catId));//坑
        }

        /// <summary>
        /// 根据编号查找产品
        /// </summary>
        /// <param name="proNum"></param>
        /// <returns></returns>
        public List<ProductInfo> GetProductInfoByProNum(string proNum)
        {
            return dal.GetProductInfoByProNum(proNum);
        }

        /// <summary>
        /// 根据的是商品类别的id查询该类别下所有的产品
        /// </summary>
        /// <param name="catId">类别的id</param>
        /// <returns></returns>
        public List<ProductInfo> GetProductInfoByCatId(int catId)
        {
            return dal.GetProductInfoByCatId(catId);
        }
        /// <summary>
        /// 增加或者是修改产品
        /// </summary>
        /// <param name="pro">产品对象</param>
        /// <param name="temp">3---新增,4----修改</param>
        /// <returns></returns>
        public bool SaveProduct(ProductInfo pro, int temp)
        {
            int r = 0;
            if (temp == 3)//新增
            {
                r = dal.AddProductInfo(pro);
            }
            else if (temp == 4)//修改
            {
                r = dal.UpdateProductInfo(pro);
            }
            return r > 0;

        }

        /// <summary>
        /// 根据id查询对象
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ProductInfo GetProductInfoById(int id)
        {
            return dal.GetProductInfoById(id);
        }


            /// <summary>
            /// 软删除产品
            /// </summary>
            /// <param name="id">id</param>
            /// <returns></returns>
            public bool SoftDeleteProductInfoByProId(int id)
        {
            return dal.SoftDeleteProductInfoByProId(id) > 0;
        }


            /// <summary>
            /// 查询所有的产品
            /// </summary>
            /// <param name="delFlag"></param>
            /// <returns></returns>
            public List<ProductInfo> GetAllProductInfoByDelFlag(int delFlag)
        {
            return dal.GetAllProductInfoByDelFlag(delFlag);
        }
    }
}
