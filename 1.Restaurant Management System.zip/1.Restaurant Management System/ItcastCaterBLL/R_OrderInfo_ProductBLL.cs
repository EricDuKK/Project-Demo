﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class R_OrderInfo_ProductBLL
    {


        R_OrderInfo_ProductDAL dal = new R_OrderInfo_ProductDAL();

        /// <summary>
        /// 退菜
        /// </summary>
        /// <param name="rOrderProId">中间表的主键id</param>
        /// <returns></returns>
        public bool SoftDeleteROrderProName(int rOrderProId)
        {
            return dal.SoftDeleteROrderProName(rOrderProId) > 0;
        }

        /// <summary>
        /// 添加产品
        /// </summary>
        /// <param name="rop"></param>
        /// <returns></returns>
        public bool AddROrderInfoProduct(R_OrderInfo_Product rop)
        {
            return dal.AddROrderInfoProduct(rop)>0;
        }

            /// <summary>
            /// 根据订单的id查询该订单的总金额和数量
            /// </summary>
            /// <param name="orderId"></param>
            /// <returns></returns>
            public R_OrderInfo_Product GetMoneyAndCount(int orderId)
        {
            return dal.GetMoneyAndCount(orderId);
        }

            /// <summary>
            /// 根据订单的id查询点了什么产品
            /// </summary>
            /// <param name="orderId">订单的id</param>
            /// <returns></returns>
            public List<R_OrderInfo_Product> GetROrderInfoProduct(int orderId)
        {
            return dal.GetROrderInfoProduct(orderId);
        }
    }
 }
