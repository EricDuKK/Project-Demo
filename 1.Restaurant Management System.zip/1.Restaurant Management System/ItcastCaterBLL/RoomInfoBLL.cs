﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{

    public class RoomInfoBLL
    {
        RoomInfoDAL dal = new RoomInfoDAL();


        /// <summary>
        /// 根据房间Id获得房间对象
        /// </summary>
        /// <param name="roomId">房间ID</param>
        /// <returns></returns>
        public RoomInfo GetRoomInfoByRoomID(int roomId)
        {
            return dal.GetRoomInfoByRoomID(roomId); 
        }

        /// <summary>
        /// 根据房间Id删除房间
        /// </summary>
        /// <param name="roomId">房间Id</param>
        /// <returns></returns>
        public bool SoftDeleteRoomInfoByRoomId(int roomId)
        {
            return dal.SoftDeleteRoomInfoByRoomId(roomId) > 0;
        }

        /// <summary>
        /// 更新房间信息
        /// </summary>
        /// <param name="room">RoomInfo对象</param>
        /// <returns></returns>
        public bool UpdateRoomInfoByRoomId(RoomInfo room)
        {
            return dal.UpdateRoomInfoByRoomId(room) >0 ;
        }

        public bool AddRoom(RoomInfo room)
        {
            return dal.AddRoom(room) > 0;
        }

        /// <summary>
        /// 获取所有的房间
        /// </summary>
        /// <param name="delFlag"></param>
        /// <returns></returns>
        public List<RoomInfo> GetAllRoomInfoByDelFlag(int delFlag)
        {
            return dal.GetAllRoomInfoByDelFlag(delFlag);
        }
    }
}
