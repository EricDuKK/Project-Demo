﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class MemberInfoBLL
    {
        MemberInfoDAL memberInfoDAL = new MemberInfoDAL();

        /// <summary>
        /// 根据会员的名字或者编号查找会员
        /// </summary>
        /// <param name="name"></param>
        /// <param name="temp"></param>
        /// <returns></returns>
        public List<MemberInfo> GetMemmberInfoByNameOrNum(string name, int temp)
        {
            return memberInfoDAL.GetMemmberInfoByNameOrNum(name, temp);
        }

        /// <summary>
        /// 根据会员的id更新会员的卡内的钱
        /// </summary>
        /// <param name="MemmberId"></param>
        /// <param name="MemMoney"></param>
        /// <returns></returns>
        public bool UpdateMoneyByMemId(int MemmberId, decimal MemMoney)
        {
            return memberInfoDAL.UpdateMoneyByMemId(MemmberId, MemMoney) > 0;
        }

        /// <summary>
        /// 根据会员的id查该会员的级别
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string GetMemmberTypeNameByMemmberId(int id)
        {
            return memberInfoDAL.GetMemmberTypeNameByMemmberId(id);
        }


        /// <summary>
        /// 新增或者修改会员信息
        /// </summary>
        /// <param name="info">会员对象</param>
        /// <param name="temp">标识 1--新增，2--修改</param>
        /// <returns>成功或者失败</returns>
        public bool SaveMemberInfo(MemberInfo info, int temp)
        {
            int r = -1;

            if(temp==1)//新增
            {
                r= memberInfoDAL.AddMemberInfo(info);
            }
            else if(temp==2)//修改
            {
                r= memberInfoDAL.UpdateMemberInfo(info);
            }

            return r > 0 ? true:false;
        }


        /// <summary>
        /// 根据ID查对象
        /// </summary>
        /// <param name="id">会员的ID</param>
        /// <returns>会员对象</returns>
        public MemberInfo GetMemberInfoByMemberId(int id)
        {
            return memberInfoDAL.GetMemberInfoByMemberId(id);   
        }

            /// <summary>
            /// 根据ID修改会员的删除标识
            /// </summary>
            /// <param name="memberId">会员的ID</param>
            /// <returns>判断是否更新成功的bool</returns>
            public bool DeleteMemberInfoByMemberId(int memberId)
        {
           return  memberInfoDAL.DeleteMemberInfoByMemberId(memberId) > 0 ? true : false;
        }



            /// <summary>
            /// 根据删除标识查询所有没有删除的会员
            /// </summary>
            /// <param name="delFlag">删除标识，，==0---未删除，1---删除</param>
            /// <returns>所有会员对象的集合</returns>
            public List<MemberInfo> GetAllMemberInfoByDelFlag(int delFlag)
        {
            return memberInfoDAL.GetAllMemberInfoByDelFlag(delFlag);
        }



    }
}
