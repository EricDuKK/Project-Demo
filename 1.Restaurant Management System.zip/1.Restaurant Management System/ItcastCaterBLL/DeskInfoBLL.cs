﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class DeskInfoBLL
    {
        DeskInfoDAL dal = new DeskInfoDAL();

        /// <summary>
        /// 计算空桌子数量
        /// </summary>
        /// <returns></returns>
        public int GetEmptyNumberDesk()
        {
            return dal.GetEmptyNumberDesk();
        }

            /// <summary>
            /// 计算桌子总数
            /// </summary>
            /// <returns></returns>
            public int GetTotalNumberOfDesk()
            {
            return dal.GetTotalNumberOfDesk();
            }
            /// <summary>
            /// 查询同一房间下的餐桌数量
            /// </summary>
            /// <param name="roomId"></param>
            /// <returns></returns>
            public bool GetDeskNumberByRoomId(int roomId)
            {
           return dal.GetDeskNumberByRoomId(roomId) > 0;    
            }

            /// <summary>
            /// 软删除
            /// </summary>
            /// <param name="deskId"></param>
            /// <returns></returns>
            public bool SoftDeleteDeskInfo(int deskId)
            {
            return dal.SoftDeleteDeskInfo(deskId) >0 ;
            }

            /// <summary>
            /// 根据餐桌id 更新餐桌信息
            /// </summary>
            /// <param name="desk">餐桌对象</param>
            /// <returns></returns>
            public bool UpdateDeskInfoByDeskId(DeskInfo desk)
            {
            return dal.UpdateDeskInfoByDeskId(desk) > 0;
            }


            /// <summary>
            /// 根据deskId得到的DeskInfo对象
            /// </summary>
            /// <param name="deskId">餐桌id</param>
            /// <returns></returns>
            public DeskInfo GetDeskInfoByDeskId(int deskId)
            {
            return dal.GetDeskInfoByDeskId(deskId);
            }

        /// <summary>
        /// 房间管理添加桌子
        /// </summary>
        /// <param name="desk">桌子对象</param>
        /// <returns></returns>
        public bool InsertDeskInfoByDefault(DeskInfo desk)
        {
        return dal.InsertDeskInfoByDefault(desk)>0;
        }

        /// <summary>
        ///  房间管理加载所有餐桌
        /// </summary>
        /// <param name="p">加载所有标识为0</param>
        /// <returns></returns>
        public List<DeskInfo> GetAllDeskInfoByDefaultFlag(int p)
        {
        return dal.GetAllDeskInfoByDefaultFlag(p);
        }

        /// <summary>
        /// 更改餐桌的状态
        /// </summary>
        /// <param name="deskId"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public bool UpdateDeskStateByDeskId(int deskId, int state)
        {
        return dal.UpdateDeskStateByDeskId(deskId, state)>0;
        }

        /// <summary>
        /// 根据房间的id查询该房间下的餐桌
        /// </summary>
        /// <param name="roomId"></param>
        /// <returns></returns>
        public List<DeskInfo> GetAllDeskInfoByRoomId(int roomId)
        {
            return dal.GetAllDeskInfoByRoomId(roomId);
        }
    }
}
