﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.DAL;
using ItcastCater.Model;

namespace ItcastCater.BLL
{
    public class OrderInfoBLL
    {
        OrderInfoDAL dal = new OrderInfoDAL();


      

            /// <summary>
            /// 根据桌子id的到桌子状态
            /// </summary>
            /// <param name="deskId"></param>
            /// <returns></returns>
            public int GetDeskStateByDeskId(int deskId)
        {
            return Convert.ToInt32(dal.GetDeskStateByDeskId(deskId));
        }

            /// <summary>
            /// 更新订单
            /// </summary>
            /// <param name="order"></param>
            /// <returns></returns>
            public bool UpdateOrderInfoMoney(OrderInfo order)
        {
            return dal.UpdateOrderInfoMoney(order) > 0;
        }

        /// <summary>
        /// 根据订单查询该订单的消费金额
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public decimal GetMoney(int orderId)
        {
            return Convert.ToDecimal(dal.GetMoney(orderId));
        }

        /// <summary>
        /// 根据订单查询该订单的消费开始时间
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public DateTime GetBeginTime(int orderId)
        {   
            DateTime beginTime = DateTime.Now;
            if(dal.GetBeginTime(orderId) != null && orderId !=0)
            {
                beginTime = Convert.ToDateTime(dal.GetBeginTime(orderId));
            }
            return beginTime;
        }

        /// <summary>
        /// 根据订单的id和消费的金额进行更新
        /// </summary>
        /// <param name="orderId">订单的id</param>
        /// <param name="money">金额</param>
        /// <returns></returns>
        public bool UpdateMoney(int orderId, decimal money,DateTime beginTime)
        {
           return dal.UpdateMoney(orderId, money,beginTime) > 0;
        }

        /// <summary>
        /// 根据餐桌的id查找该餐桌正在使用的订单id
        /// </summary>
        /// <param name="deskId">餐桌的id</param>
        /// <returns>订单的id</returns>
        public int GetOrderIdByDeskId(int deskId)
        {
            return Convert.ToInt32(dal.GetOrderIdByDeskId(deskId));
        }

        /// <summary>
        /// 添加一个订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public int AddOrderInfo(OrderInfo order)
        {
            return Convert.ToInt32(dal.AddOrderInfo(order));
        }
    }
}
