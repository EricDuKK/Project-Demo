﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SQLite;
using ItcastCater.Model;

namespace ItcastCater.DAL
{
    public class MemberInfoDAL
    {
        /// <summary>
        /// 根据会员的名字或者编号查找会员
        /// </summary>
        /// <param name="name"></param>
        /// <param name="temp"></param>
        /// <returns></returns>
        public List<MemberInfo> GetMemmberInfoByNameOrNum(string name, int temp)
        {
            string sql = "select * from MemmberInfo where DelFlag=0";
            if (temp == 1)
            {
                sql += " and MemName like @MemName";
            }
            else if (temp == 2)
            {
                sql += " and MemNum like @MemName";
            }
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@MemName", "%" + name + "%"));
            List<MemberInfo> list = new List<MemberInfo>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToMemberInfo(dr));
                }
            }
            return list;
        }
        /// <summary>
        /// 根据会员的id更新会员的卡内的钱
        /// </summary>
        /// <param name="MemmberId"></param>
        /// <param name="MemMoney"></param>
        /// <returns></returns>
        public int UpdateMoneyByMemId(int MemmberId, decimal MemMoney)
        {
            string sql = "update MemmberInfo set MemMoney=@MemMoney where DelFlag=0 and MemmberId=@MemmberId";
            return SqliteHelper.ExecuteNonQuery(sql, new SQLiteParameter("@MemMoney", MemMoney), new SQLiteParameter("@MemmberId", MemmberId));
        }


        /// <summary>
        /// 根据会员的id查该会员的级别
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string GetMemmberTypeNameByMemmberId(int id)
        {
            string sql = "select MemTpName from MemmberType inner join MemmberInfo on MemmberInfo.MemType=MemmberType.MemType where MemmberId=" + id;
            return SqliteHelper.ExecuteScalar(sql).ToString();
        }

        //新增
        public int AddMemberInfo(MemberInfo member)
        {
            string sql = "insert into MemmberInfo (MemName,MemMobilePhone,MemAddress,MemType,MemNum,MemGender,MemDiscount,MemMoney,DelFlag,SubTime,MemIntegral,MemEndServerTime,MemBirthdaty) values(@MemName,@MemMobilePhone,@MemAddress,@MemType,@MemNum,@MemGender,@MemDiscount,@MemMoney,@DelFlag,@SubTime,@MemIntegral,@MemEndServerTime,@MemBirthdaty)"; 
            return AddAndUpdateMemberInfo(1,sql,member);
        }

        //修改
        public int UpdateMemberInfo(MemberInfo member)
        {
            string sql = "update MemmberInfo set MemName=@MemName,MemMobilePhone=@MemMobilePhone,MemAddress=@MemAddress,MemType=@MemType,MemNum=@MemNum,MemGender=@MemGender,MemDiscount=@MemDiscount,MemMoney=@MemMoney,MemIntegral=@MemIntegral,MemEndServerTime=@MemEndServerTime,MemBirthdaty=@MemBirthdaty where MemmberId=@MemmberId";
            return AddAndUpdateMemberInfo(2, sql, member);
        }

        private int AddAndUpdateMemberInfo(int temp, string sql, MemberInfo mem)
        {
            #region 参数
            SQLiteParameter[] ps = {
                   new SQLiteParameter("@MemName",mem.MemName),
                   new SQLiteParameter("@MemMobilePhone",mem.MemMobilePhone),
                   new SQLiteParameter("@MemAddress",mem.MemAddress),
                   new SQLiteParameter("@MemType",mem.MemType),
                   new SQLiteParameter("@MemNum",mem.MemNum),
                   new SQLiteParameter("@MemGender",mem.MemGender),
                   new SQLiteParameter("@MemDiscount",mem.MemDiscount),
                   new SQLiteParameter("@MemMoney",mem.MemMoney),
                   new SQLiteParameter("@MemIntegral",mem.MemIntegral),
                   new SQLiteParameter("@MemEndServerTime",mem.MemEndServerTime),
                   new SQLiteParameter("@MemBirthdaty",mem.MemBirthdaty)
                                   };
            List<SQLiteParameter> list = new List<SQLiteParameter>();
            list.AddRange(ps);
            
            if(temp==1)
            {
                list.Add(new SQLiteParameter("@DelFlag",mem.DelFlag));
                list.Add(new SQLiteParameter("@SubTime",mem.SubTime));
            }
            if(temp==2)
            {
                list.Add(new SQLiteParameter("@MemmberId",mem.MemmberId));
            }
            #endregion
            return SqliteHelper.ExecuteNonQuery(sql,list.ToArray());

        }





        /// <summary>
        /// 根据ID查对象
        /// </summary>
        /// <param name="id">会员的ID</param>
        /// <returns>会员对象</returns>

        public MemberInfo GetMemberInfoByMemberId(int id)
        {
            string sql = "select * from MemmberInfo where DelFlag=0 and MemmberId=" + id;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            MemberInfo memberInfo = new MemberInfo();
            if(dt.Rows.Count > 0)
            {
                memberInfo = RowToMemberInfo(dt.Rows[0]);
            }

            return memberInfo;
        }


        /// <summary>
        /// 根据ID修改会员的删除标识
        /// </summary>
        /// <param name="memberId">会员的ID</param>
        /// <returns>受影响的行数</returns>
        public int DeleteMemberInfoByMemberId(int memberId)
        {
            string sql = "update MemmberInfo set DelFlag = 1 where MemmberId =" + memberId;
            return SqliteHelper.ExecuteNonQuery(sql);
        }


        /// <summary>
        /// 根据删除标识查询所有没有删除的会员
        /// </summary>
        /// <param name="delFlag">删除标识，，==0---未删除，1---删除</param>
        /// <returns>所有会员对象的集合</returns>
        public List<MemberInfo> GetAllMemberInfoByDelFlag(int delFlag)
        {
            string sql = "select MemmberId,MemName,MemMobilePhone,MemAddress,MemType,MemNum,MemGender,MemDiscount," +
                         "MemMoney,SubTime,MemIntegral,MemEndServerTime,MemBirthdaty from MemmberInfo where DelFlag = @DelFlag";
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@DelFlag", delFlag));
            List<MemberInfo> list = new List<MemberInfo>();
            if(dt.Rows.Count > 0)
            {
                foreach(DataRow dr in dt.Rows)
                {
                    MemberInfo memberInfo = RowToMemberInfo(dr);
                    list.Add(memberInfo);
                }
            }
            return list;

        }

        //关系转对象
        private MemberInfo RowToMemberInfo(DataRow dr)
        {
            MemberInfo mem = new MemberInfo();
            mem.MemAddress = dr["MemAddress"].ToString();
            mem.MemBirthdaty = Convert.ToDateTime(dr["MemBirthdaty"]);
            mem.MemDiscount = Convert.ToDecimal(dr["MemDiscount"]);
            mem.MemEndServerTime = Convert.ToDateTime(dr["MemEndServerTime"]);
            mem.MemGender = dr["MemGender"].ToString();
            mem.MemIntegral = Convert.ToInt32(dr["MemIntegral"]);
            mem.MemmberId = Convert.ToInt32(dr["MemmberId"]);
            mem.MemMobilePhone = dr["MemMobilePhone"].ToString();
            mem.MemMoney = Convert.ToDecimal(dr["MemMoney"]);
            mem.MemName = dr["MemName"].ToString();
            mem.MemNum = dr["MemNum"].ToString();
            mem.MemPhone = mem.MemMobilePhone;//小坑 有没有都可以
            //mem.MemTpName==坑
            mem.MemType = Convert.ToInt32(dr["MemType"]);
            mem.SubTime = Convert.ToDateTime(dr["SubTime"]);
            return mem;
        }
    }
}
