﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SQLite;
using ItcastCater.Model;

namespace ItcastCater.DAL
{
    public class OrderInfoDAL
    {
        /// <summary>
        /// 根据桌子id的到桌子状态
        /// </summary>
        /// <param name="deskId"></param>
        /// <returns></returns>
        public object GetDeskStateByDeskId(int deskId)
        {
            string sql = "select OrderState from OrderInfo where OrderId=@OrderId and DelFlag=0";
            return SqliteHelper.ExecuteScalar(sql, new SQLiteParameter("@OrderId", deskId));
        }

        /// <summary>
        /// 更新订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public int UpdateOrderInfoMoney(OrderInfo order)
        {
            string sql = "update OrderInfo set OrderState=2,EndTime=@EndTime,OrderMoney=@OrderMoney where OrderId=@OrderId";


            SQLiteParameter[] ps = {
              new SQLiteParameter("@EndTime",order.EndTime),
               new SQLiteParameter("@OrderMoney",order.OrderMoney),
                          new SQLiteParameter("@OrderId",order.OrderId)

                                  };
            return SqliteHelper.ExecuteNonQuery(sql, ps);

        }

        /// <summary>
        /// 根据订单查询该订单的消费金额
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public object GetMoney(int orderId)
        {
            string sql = "select OrderMoney from OrderInfo where OrderId=@OrderId and OrderState=1 and DelFlag=0";
            return SqliteHelper.ExecuteScalar(sql, new SQLiteParameter("@OrderId", orderId));
        }

        /// <summary>
        /// 根据订单查询该订单的消费开始时间
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        public object GetBeginTime(int orderId)
        {
            string sql = "select BeginTime from OrderInfo where OrderId=@OrderId and OrderState=1 and DelFlag=0";
            return SqliteHelper.ExecuteScalar(sql, new SQLiteParameter("@OrderId", orderId));
        }


        /// <summary>
        /// 根据订单的id和消费的金额进行更新
        /// </summary>
        /// <param name="orderId">订单的id</param>
        /// <param name="money">金额</param>
        /// <returns></returns>
        public int UpdateMoney(int orderId, decimal money,DateTime beginTime)
        {
            string sql = "update OrderInfo set OrderMoney=@OrderMoney,BeginTime=@BeginTime where OrderId=@OrderId and DelFlag=0";
            return SqliteHelper.ExecuteNonQuery(sql, new SQLiteParameter("@OrderMoney", money), new SQLiteParameter("@OrderId", orderId),new SQLiteParameter("@BeginTime", beginTime));

        }
    
        /// <summary>
        /// 根据餐桌的id查找该餐桌正在使用的订单id
        /// </summary>
        /// <param name="deskId">餐桌的id</param>
        /// <returns>订单的id</returns>
        public object GetOrderIdByDeskId(int deskId)
        {
            string sql = "select OrderInfo.OrderId from R_Order_Desk inner join OrderInfo on R_Order_Desk.OrderId=OrderInfo.OrderId where OrderInfo.OrderState=1 and DeskId=" + deskId;
            return SqliteHelper.ExecuteScalar(sql);
        }

        /// <summary>
        /// 添加一个订单
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        public object AddOrderInfo(OrderInfo order)
        {
            string sql = "insert into OrderInfo (SubTime,BeginTime,Remark,OrderState,DelFlag,SubBy,OrderMoney) values(@SubTime,@BeginTime,@Remark,@OrderState,@DelFlag,@SubBy,@OrderMoney);select last_insert_rowid();";
            SQLiteParameter[] ps = {
                new SQLiteParameter("@SubTime",order.SubTime),
                new SQLiteParameter("@Remark",order.Remark),
                new SQLiteParameter("@OrderState",order.OrderState),
                new SQLiteParameter("@DelFlag",order.DelFlag),
                new SQLiteParameter("@SubBy",order.SubBy),
                new SQLiteParameter("@BeginTime",order.BeginTime),
                new SQLiteParameter("@OrderMoney",order.OrderMoney)
                                  };
            return SqliteHelper.ExecuteScalar(sql, ps);
        }
    }
}
