﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.Model;
using System.Data;
using System.Data.SQLite;

namespace ItcastCater.DAL
{
    public class CategoryInfoDAL
    {
        /// <summary>
        /// 根据商品类别的id删除该类别
        /// </summary>
        /// <param name="catId"></param>
        /// <returns></returns>
        public int SoftDelelteCategoryInfoByCatId(int catId)
        {
            string sql = "update CategoryInfo set DelFlag=1 where CatId=" + catId;
            return SqliteHelper.ExecuteNonQuery(sql);
        }

        //添加
        public int AddCategoryInfo(CategoryInfo ct)
        {
            string sql = "insert into CategoryInfo (CatName,CatNum,Remark,DelFlag,SubTime,SubBy) values(@CatName,@CatNum,@Remark,@DelFlag,@SubTime,@SubBy)";

            return AddAndUpdateCategoryInfo(sql, 1, ct);
        }
        //修改
        public int UpdateCategory(CategoryInfo ct)
        {
            string sql = "update CategoryInfo set CatName=@CatName,CatNum=@CatNum,Remark=@Remark where CatId=@CatId";
            return AddAndUpdateCategoryInfo(sql, 2, ct);
        }
        private int AddAndUpdateCategoryInfo(string sql, int temp, CategoryInfo ct)
        {
            SQLiteParameter[] ps = {
                   new SQLiteParameter("@CatName",ct.CatName),
                    new SQLiteParameter("@CatNum",ct.CatNum),
                     new SQLiteParameter("@Remark",ct.Remark)
                                  };
            List<SQLiteParameter> list = new List<SQLiteParameter>();
            list.AddRange(ps);
            if (temp == 1)//新增
            {
                list.Add(new SQLiteParameter("@DelFlag", ct.DelFlag));
                list.Add(new SQLiteParameter("@SubTime", ct.SubTime));
                list.Add(new SQLiteParameter("@SubBy", ct.SubBy));
            }
            else if (temp == 2)//修改
            {
                list.Add(new SQLiteParameter("@CatId", ct.CatId));
            }
            return SqliteHelper.ExecuteNonQuery(sql, list.ToArray());
        }


        /// <summary>
        /// 根据类别的id查询类别对象
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public CategoryInfo GetCategoryInfoById(int id)
        {
            //string sql = "select CatName,CatNum,Remark from CategoryInfo where DelFlag=0 and CatId=" + id;
            string sql = "select * from CategoryInfo where DelFlag=0 and CatId="+id;
            CategoryInfo ct = null;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            if (dt.Rows.Count > 0)
            {
                ct = RowToCategoryInfo(dt.Rows[0]);
            }
            return ct;
        }

        /// <summary>
        /// 查询所有的商品类别
        /// </summary>
        /// <param name="delFlag"></param>
        /// <returns></returns>
        public List<CategoryInfo> GetAllCategoryInfoByDelFlag(int delFlag)
        {
            string sql = "select CatId,CatName,CatNum,Remark from CategoryInfo where DelFlag=" + delFlag;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            List<CategoryInfo> list = new List<CategoryInfo>();
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToCategoryInfo(dr));
                }
            }
            return list;
        }
        //关系转对象
        private CategoryInfo RowToCategoryInfo(DataRow dr)
        {
            CategoryInfo ct = new CategoryInfo();
            // if (tp==1)//查询带id
            //{
            ct.CatId = Convert.ToInt32(dr["CatId"]);
            //}

            ct.CatName = dr["CatName"].ToString();
            ct.CatNum = dr["CatNum"].ToString();
            ct.Remark = dr["Remark"].ToString();
            return ct;
        }
    }
}
