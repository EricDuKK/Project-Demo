﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.Model;
using System.Data;
using System.Data.SQLite;

namespace ItcastCater.DAL
{
    public class UserInfoDAL
    {
        
        /// <summary>
        /// 该方法根据账号去数据库查询，返回的是对象
        /// </summary>
        /// <param name="LoginName">登录的账号</param>
        /// <returns>userInfo对象</returns>
        public UserInfo IsLoginByLoginName(string LoginName)
        {
            string sql = "select * from UserInfo where LoginUserName = @LoginUserName";
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@LoginUserName",LoginName));

            UserInfo userInfo = null;
            if(dt.Rows.Count > 0)
            {
                foreach(DataRow dr in dt.Rows)
                {
                    userInfo = RowToUserInfo(dr);
                }
            }

            return userInfo;
        }

        //关系转对象
        private UserInfo RowToUserInfo(DataRow dr)
        {
            UserInfo userInfo = new UserInfo();
            userInfo.DelFlag = Convert.ToInt32(dr["DelFlag"]);
            userInfo.LastLoginIP = dr["LastLoginIP"].ToString();
            userInfo.UserId =Convert.ToInt32(dr["UserId"]);
            userInfo.Pwd = dr["Pwd"].ToString();
            userInfo.UserName = dr["UserName"].ToString();
            userInfo.LoginUserName = dr["LoginUserName"].ToString();
            userInfo.LastLoginTime = Convert.ToDateTime(dr["LastLoginTime"]);
            userInfo.SubTime = Convert.ToDateTime(dr["SubTime"]);
            return userInfo;
        }
    }
}
