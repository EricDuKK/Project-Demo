﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.Model;
using System.Data;
using System.Data.SQLite;

namespace ItcastCater.DAL
{
    public class ProductInfoDAL
    {
        /// <summary>
        /// 根据拼音或者编号查询产品
        /// </summary>
        /// <param name="num">可以是拼音，可以是编号</param>
        /// <param name="temp">1---拼音，2---编号</param>
        /// <returns></returns>
        public List<ProductInfo> GetProductInfoBySpellOrNum(string num, int temp)
        {
            string sql = "select * from ProductInfo where DelFlag=0";
            if (temp == 1)//拼音
            {
                sql += " and ProSpell like @ProSpell";
            }
            else if (temp == 2)
            {
                sql += " and ProNum like @ProSpell";
            }
            List<ProductInfo> list = new List<ProductInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@ProSpell", "%" + num + "%"));
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToProductInfo(dr));
                }
            }
            return list;
        }


        /// <summary>
        /// 根据商品类别的id查询该类别下有没有产品
        /// </summary>
        /// <param name="catId"></param>
        /// <returns></returns>
        public object GetProductInfoCountByCatId(int catId)
        {
            string sql = "select count(*) from ProductInfo where DelFlag=0 and CatId=" + catId;
            return SqliteHelper.ExecuteScalar(sql);
        }

        /// <summary>
        /// 根据编号查找产品
        /// </summary>
        /// <param name="proNum"></param>
        /// <returns></returns>
        public List<ProductInfo> GetProductInfoByProNum(string proNum)
        {
            string sql = "select * from ProductInfo where DelFlag=0 and ProNum like @ProNum";
            List<ProductInfo> list = new List<ProductInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@ProNum", "%" + proNum + "%"));
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToProductInfo(dr));
                }
            }
            return list;

        }

        /// <summary>
        /// 根据的是商品类别的id查询该类别下所有的产品
        /// </summary>
        /// <param name="catId">类别的id</param>
        /// <returns></returns>
        public List<ProductInfo> GetProductInfoByCatId(int catId)
        {
            string sql = "select * from ProductInfo where DelFlag=0 and CatId=" + catId;
            List<ProductInfo> list = new List<ProductInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToProductInfo(dr));
                }
            }
            return list;
        }

        //新增
        public int AddProductInfo(ProductInfo pro)
        {
            string sql = "insert into ProductInfo(CatId,ProName,ProCost,ProSpell,ProPrice,ProUnit,Remark,DelFlag,SubTime,ProStock,ProNum,SubBy) values(@CatId,@ProName,@ProCost,@ProSpell,@ProPrice,@ProUnit,@Remark,@DelFlag,@SubTime,@ProStock,@ProNum,@SubBy)";
            return AddAndUpdate(pro, sql, 3);
        }
        //修改
        public int UpdateProductInfo(ProductInfo pro)
        {
            string sql = "update ProductInfo set CatId=@CatId,ProName=@ProName,ProCost=@ProCost,ProSpell=@ProSpell,ProPrice=@ProPrice,ProUnit=@ProUnit,Remark=@Remark,ProStock=@ProStock,ProNum=@ProNum where ProId=@ProId";
            return AddAndUpdate(pro, sql, 4);
        }

        private int AddAndUpdate(ProductInfo pro, string sql, int temp)
        {
            SQLiteParameter[] ps = {
                    new SQLiteParameter("@CatId",pro.CatId),
                    new SQLiteParameter("@ProName",pro.ProName),
                    new SQLiteParameter("@ProCost",pro.ProCost),
                    new SQLiteParameter("@ProSpell",pro.ProSpell),
                    new SQLiteParameter("@ProPrice",pro.ProPrice),
                    new SQLiteParameter("@ProUnit",pro.ProUnit),
                    new SQLiteParameter("@Remark",pro.Remark),
                    new SQLiteParameter("@ProStock",pro.ProStock),
                    new SQLiteParameter("@ProNum",pro.ProNum)
                                   };
            List<SQLiteParameter> list = new List<SQLiteParameter>();
            list.AddRange(ps);

            if (temp == 3)//新增
            {
                list.Add(new SQLiteParameter("@DelFlag", pro.DelFlag));
                list.Add(new SQLiteParameter("@SubTime", pro.SubTime));
                list.Add(new SQLiteParameter("@SubBy", pro.SubBy));
            }
            else if (temp == 4)//修改
            {
                list.Add(new SQLiteParameter("@ProId", pro.ProId));
            }
            return SqliteHelper.ExecuteNonQuery(sql, list.ToArray());
        }

        /// <summary>
        /// 根据id查询对象
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ProductInfo GetProductInfoById(int id)
        {
            string sql = "select * from ProductInfo where DelFlag=0 and ProId=" + id;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            ProductInfo pro = null;
            if (dt.Rows.Count > 0)
            {
                pro = RowToProductInfo(dt.Rows[0]);
            }
            return pro;
        }

        /// <summary>
        /// 软删除产品
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        public int SoftDeleteProductInfoByProId(int id)
        {
            string sql = "update ProductInfo set DelFlag=1 where ProId=@ProId";
            return SqliteHelper.ExecuteNonQuery(sql, new SQLiteParameter("@ProId", id));
        }

        /// <summary>
        /// 查询所有的产品
        /// </summary>
        /// <param name="delFlag"></param>
        /// <returns></returns>
        public List<ProductInfo> GetAllProductInfoByDelFlag(int delFlag)
        {
            string sql = "select ProId,CatId,ProName,ProCost,ProSpell,ProPrice,ProUnit,Remark,ProStock,ProNum from ProductInfo where DelFlag=" + delFlag;

            List<ProductInfo> list = new List<ProductInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToProductInfo(dr));
                }
            }
            return list;
        }

        private ProductInfo RowToProductInfo(DataRow dr)
        {
            ProductInfo pro = new ProductInfo();
            pro.CatId = Convert.ToInt32(dr["CatId"]);
            // pro.DelFlag = Convert.ToInt32(dr["DelFlag"]);
            pro.ProCost = Convert.ToDecimal(dr["ProCost"]);
            pro.ProId = Convert.ToInt32(dr["ProId"]);
            pro.ProName = dr["ProName"].ToString();
            pro.ProNum = dr["ProNum"].ToString();
            pro.ProPrice = Convert.ToDecimal(dr["ProPrice"]);
            pro.ProSpell = dr["ProSpell"].ToString();
            pro.ProStock = Convert.ToDecimal(dr["ProStock"]);
            pro.ProUnit = dr["ProUnit"].ToString();
            pro.Remark = dr["Remark"].ToString();
            // pro.SubBy = Convert.ToInt32(dr["SubBy"]);
            // pro.SubTime = Convert.ToDateTime(dr["SubTime"]);
            return pro;
        }
    }
}
