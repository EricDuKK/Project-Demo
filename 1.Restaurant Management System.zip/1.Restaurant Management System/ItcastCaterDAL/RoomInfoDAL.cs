﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.Model;
using System.Data;
using System.Data.SQLite;

namespace ItcastCater.DAL
{
    public class RoomInfoDAL
    {
        /// <summary>
        /// 根据房间Id获得房间对象
        /// </summary>
        /// <param name="roomId">房间ID</param>
        /// <returns></returns>
        public RoomInfo GetRoomInfoByRoomID(int roomId)
        {
            string sql = "select * from RoomInfo where DelFlag=0 and RoomId = " + roomId;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            RoomInfo roomInfo = new RoomInfo();
            if(dt.Rows.Count > 0)
            {
               roomInfo = RowToRoomInfo(dt.Rows[0]);
            }
            return roomInfo;
        }

        /// <summary>
        /// 根据房间Id删除房间
        /// </summary>
        /// <param name="roomId">房间Id</param>
        /// <returns></returns>
        public int SoftDeleteRoomInfoByRoomId(int roomId)
        {
            string sql = "Update RoomInfo set DelFlag=1 where roomId= " + roomId;
            return SqliteHelper.ExecuteNonQuery(sql);
        }

        /// <summary>
        ///  更新房间信息
        /// </summary>
        /// <param name="room">RoomInfo对象</param>
        /// <returns></returns>
        public int UpdateRoomInfoByRoomId(RoomInfo room)
        {
            string sql = "Update RoomInfo set RoomName=@RoomName, RoomMinimunConsume=@RoomMinimunConsume, RoomMaxConsumer=@RoomMaxConsumer, IsDefault=@IsDefault, RoomType=@RoomType where RoomId=@RoomId";
            SQLiteParameter[] ps = {
                new SQLiteParameter("@RoomName",room.RoomName),
                new SQLiteParameter("@RoomMinimunConsume",room.RoomMinimunConsume),
                new SQLiteParameter("@RoomMaxConsumer",room.RoomMaxConsumer),
                new SQLiteParameter("@IsDefault",room.IsDefault),
                new SQLiteParameter("@RoomType",room.RoomType),
                new SQLiteParameter("@RoomId",room.RoomId)
                                    };
            return SqliteHelper.ExecuteNonQuery(sql,ps); 
        }


        public int AddRoom(RoomInfo room)
        {
            string sql = "insert into RoomInfo (RoomName,RoomType,RoomMinimunConsume,RoomMaxConsumer,IsDefault,DelFlag,SubTime,SubBy) values(@RoomName,@RoomType,@RoomMinimunConsume,@RoomMaxConsumer,@IsDefault,@DelFlag,@SubTime,@SubBy)";

            SQLiteParameter[] ps = {
            new SQLiteParameter("@RoomName",room.RoomName),
            new SQLiteParameter("@RoomType",room.RoomType),
            new SQLiteParameter("@RoomMinimunConsume",room.RoomMinimunConsume),
            new SQLiteParameter("@RoomMaxConsumer",room.RoomMaxConsumer),
            new SQLiteParameter("@IsDefault",room.IsDefault),
            new SQLiteParameter("@DelFlag",room.DelFlag),
            new SQLiteParameter("@SubTime",room.SubTime),
            new SQLiteParameter("@SubBy",room.SubBy)
                                  };
            return SqliteHelper.ExecuteNonQuery(sql, ps);
        }



        /// <summary>
        /// 获取所有的房间
        /// </summary>
        /// <param name="delFlag"></param>
        /// <returns></returns>
        public List<RoomInfo> GetAllRoomInfoByDelFlag(int delFlag)
        {
            string sql = "select * from RoomInfo Where DelFlag=" + delFlag;
            List<RoomInfo> list = new List<RoomInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToRoomInfo(dr));
                }
            }
            return list;
        }

        private RoomInfo RowToRoomInfo(DataRow dr)
        {
            RoomInfo r = new RoomInfo();
            //r.DelFlag = dr[""].ToString();
            r.IsDefault = Convert.ToInt32(dr["IsDefault"]);
            r.RoomId = Convert.ToInt32(dr["RoomId"]);
            r.RoomMaxConsumer = Convert.ToDecimal(dr["RoomMaxConsumer"]);
            r.RoomMinimunConsume = Convert.ToDecimal(dr["RoomMinimunConsume"]);
            r.RoomName = dr["RoomName"].ToString();
            r.RoomType = Convert.ToInt32(dr["RoomType"]);
            r.SubBy = Convert.ToInt32(dr["SubBy"]);
            r.SubTime = Convert.ToDateTime(dr["SubTime"]);
            return r;
        }
    }
}
