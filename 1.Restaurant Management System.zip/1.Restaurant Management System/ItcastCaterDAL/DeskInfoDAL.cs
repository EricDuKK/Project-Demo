﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.Model;
using System.Data;
using System.Data.SQLite;

namespace ItcastCater.DAL
{
    public class DeskInfoDAL
    {
        /// <summary>
        /// 计算空桌子数量
        /// </summary>
        /// <returns></returns>
        public int GetEmptyNumberDesk()
        {
            string sql = "select * from DeskInfo where DeskState=0 and DelFlag=0";
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            return dt.Rows.Count;
        }

        /// <summary>
        /// 计算桌子总数
        /// </summary>
        /// <returns></returns>
        public int GetTotalNumberOfDesk()
        {
            string sql = "select * from DeskInfo where DelFlag=0";
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            return dt.Rows.Count;
        }

        /// <summary>
        /// 查询同一房间下的餐桌数量
        /// </summary>
        /// <param name="roomId"></param>
        /// <returns></returns>
        public int GetDeskNumberByRoomId(int roomId)
        {
            string sql = "select * from DeskInfo where DelFlag=0 and RoomId = " + roomId;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            return dt.Rows.Count; 
            
        }

        /// <summary>
        /// 软删除
        /// </summary>
        /// <param name="deskId"></param>
        /// <returns></returns>
        public int SoftDeleteDeskInfo(int deskId)
        {
            string sql = "update DeskInfo set DelFlag = 1 where DeskId = " + deskId;
            return SqliteHelper.ExecuteNonQuery(sql);
        }

        /// <summary>
        /// 根据餐桌id 更新餐桌信息
        /// </summary>
        /// <param name="desk">餐桌对象</param>
        /// <returns></returns>
        public int UpdateDeskInfoByDeskId(DeskInfo desk)
        {
            string sql = "update DeskInfo set DeskName=@DeskName,DeskRemark=@DeskRemark,DeskRegion=@DeskRegion,DeskState=@DeskState,SubTime=@SubTime,RoomId=@RoomId where DeskId=@DeskId";
            SQLiteParameter[] ps =
            {
                new SQLiteParameter("@DeskName",desk.DeskName),
                new SQLiteParameter("@DeskRemark",desk.DeskRemark),
                new SQLiteParameter("@DeskRegion",desk.DeskRegion),
                new SQLiteParameter("@DeskState" ,desk.DeskState),
                new SQLiteParameter("@DeskId",desk.DeskId),
                new SQLiteParameter("@SubTime",desk.SubTime),
                new SQLiteParameter("@RoomId",desk.RoomId)
            };
            return SqliteHelper.ExecuteNonQuery(sql, ps);
        }


        /// <summary>
        /// 根据deskId得到的DeskInfo对象
        /// </summary>
        /// <param name="deskId">餐桌id</param>
        /// <returns></returns>
        public DeskInfo GetDeskInfoByDeskId(int deskId)
        {
            DeskInfo deskInfo = new DeskInfo();
            string sql = "select * from DeskInfo where DelFlag = 0 and DeskId = " + deskId;
            DataTable dt = SqliteHelper.ExcuteTable(sql); 
            if(dt.Rows.Count > 0)
            {
               deskInfo = RowToDeskInfo(dt.Rows[0]);
            }

            return deskInfo;
        }

        /// <summary>
        /// 房间管理添加桌子
        /// </summary>
        /// <param name="desk">桌子对象</param>
        /// <returns></returns>
        public int InsertDeskInfoByDefault(DeskInfo desk)
        {
            string sql = "insert into DeskInfo (RoomId, DeskName,DeskRemark,DeskRegion,DeskState,DelFlag,SubTime,SubBy) values(@RoomId,@DeskName,@DeskRemark,@DeskRegion,@DeskState,0,@SubTime,1)";
            SQLiteParameter[] ps = {
                new SQLiteParameter("@RoomId",desk.RoomId),
                new SQLiteParameter("@DeskName",desk.DeskName),
                new SQLiteParameter("@DeskRemark",desk.DeskRemark),
                new SQLiteParameter("@DeskRegion",desk.DeskRegion),
                new SQLiteParameter("DeskState",desk.DeskState),
                new SQLiteParameter("@SubTime",desk.SubTime)
                                    };
            return SqliteHelper.ExecuteNonQuery(sql,ps);
        }

        /// <summary>
        ///  房间管理加载所有餐桌
        /// </summary>
        /// <param name="p">加载所有标识为0</param>
        /// <returns></returns>
        public List<DeskInfo> GetAllDeskInfoByDefaultFlag(int p)
        {
            string sql = "select * from DeskInfo where DelFlag=@DelFlag";
            List<DeskInfo> list = new List<DeskInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@DelFlag", p)) ;  

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToDeskInfo(dr));
                }
            }
            return list;
        }

        /// <summary>
        /// 更改餐桌的状态
        /// </summary>
        /// <param name="deskId"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public int UpdateDeskStateByDeskId(int deskId, int state)
        {
            string sql = "update DeskInfo set DeskState=@DeskState where DelFlag=0 and DeskId=@DeskId";
            return SqliteHelper.ExecuteNonQuery(sql, new SQLiteParameter("@DeskState", state), new SQLiteParameter("@DeskId", deskId));
        }

        /// <summary>
        /// 根据房间的id查询该房间下的餐桌
        /// </summary>
        /// <param name="roomId"></param>
        /// <returns></returns>
        public List<DeskInfo> GetAllDeskInfoByRoomId(int roomId)
        {
            string sql = "select * from DeskInfo where DelFlag=0 and RoomId=@RoomId";
            List<DeskInfo> list = new List<DeskInfo>();
            DataTable dt = SqliteHelper.ExcuteTable(sql, new SQLiteParameter("@RoomId", roomId));
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToDeskInfo(dr));
                }
            }
            return list;
        }

        private DeskInfo RowToDeskInfo(DataRow dr)
        {
            DeskInfo dk = new DeskInfo();
            //dk.DelFlag=
            dk.DeskId = Convert.ToInt32(dr["DeskId"]);
            dk.DeskName = dr["DeskName"].ToString();
            dk.DeskRegion = dr["DeskRegion"].ToString();
            dk.DeskRemark = dr["DeskRemark"].ToString();
            dk.DeskState = Convert.ToInt32(dr["DeskState"]);
            dk.DeskStateString = dk.DeskState == 0 ? "空闲" : "占用";
            dk.RoomId = Convert.ToInt32(dr["RoomId"]);
            dk.SubBy = Convert.ToInt32(dr["SubBy"]);
            dk.SubTime = Convert.ToDateTime(dr["SubTime"]);
            return dk;
        }
    }
}
