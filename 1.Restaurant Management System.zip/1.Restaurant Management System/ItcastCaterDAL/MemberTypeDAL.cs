﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ItcastCater.Model;
using System.Data.SQLite;
using System.Data;

namespace ItcastCater.DAL
{
    public class MemberTypeDAL
    {
        /// <summary>
        /// 查询所有的会员等级
        /// </summary>
        /// <param name="delFlag">删除标识</param>
        /// <returns>会员等级对象集合</returns>
        public List<MemberType> GetAllMemberTypeByDelFlag(int delFlag)
        {
            string sql = "select MemType,MemTpName from MemmberType where DelFlag=" + delFlag;
            DataTable dt = SqliteHelper.ExcuteTable(sql);
            List<MemberType> list = new List<MemberType>();

            if(dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(RowToMemberType(dr));
                }
            }
            return list;
        }

        //关系转对象
        private MemberType RowToMemberType(DataRow dr)
        {
            MemberType mt = new MemberType();
            mt.MemTpName = dr["MemTpName"].ToString();
            mt.MemType = Convert.ToInt32(dr["MemType"]);
            return mt;
        }
    }
}
