﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Configuration;
using System.Data;

namespace ItcastCater.DAL
{
    public class SqliteHelper
    {
        //连接字符串
        private static readonly string str = ConfigurationManager.ConnectionStrings["conStr"].ConnectionString;

        /// <summary>
        /// 增,删,改,都可以
        /// </summary>
        /// <param name="sql">sql 语句</param>
        /// <param name="ps">sql 语句中的参数</param>
        /// <returns>返回受影响的行数</returns>
        public static int ExecuteNonQuery(string sql, params SQLiteParameter[] ps)
        {
            using (SQLiteConnection con = new SQLiteConnection(str))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(sql, con))
                {
                    con.Open();
                    cmd.Parameters.AddRange(ps);
                    return cmd.ExecuteNonQuery();
                }

            }
        }

        /// <summary>
        /// 查询首行首列
        /// </summary>
        /// <param name="sql">sql 语句</param>
        /// <param name="ps">sql 语句中的参数</param>
        /// <returns>首行首列Object</returns>
        public static object ExecuteScalar(string sql, params SQLiteParameter[] ps)
        {
            using (SQLiteConnection con = new SQLiteConnection(str))
            {
                using (SQLiteCommand cmd = new SQLiteCommand(sql, con))
                {
                    con.Open();
                    cmd.Parameters.AddRange(ps);
                    return cmd.ExecuteScalar();
                }

            }
        }


        /// <summary>
        /// 查询(用的非常少）
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="ps"></param>
        /// <returns>SQLiteDataReader</returns>
        public static SQLiteDataReader ExecuteReader(string sql, params SQLiteParameter[] ps)
        {
            SQLiteConnection con = new SQLiteConnection(str);
            using (SQLiteCommand cmd = new SQLiteCommand(sql, con))
            {
                cmd.Parameters.AddRange(ps);

                try
                {
                    con.Open();
                    return cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                }
                catch (Exception ex)
                {
                    con.Close();
                    con.Dispose();
                    throw ex;
                }

            }
        }

       
        /// <summary>
        /// 查询表
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="ps"></param>
        /// <returns>一个表</returns>
        public static DataTable ExcuteTable(string sql, params SQLiteParameter[] ps)
        {
            DataTable dt = new DataTable();

            using (SQLiteDataAdapter sda = new SQLiteDataAdapter(sql, str))
            {
                sda.SelectCommand.Parameters.AddRange(ps);

                sda.Fill(dt);
            }

            return dt;
        }
    }
}
