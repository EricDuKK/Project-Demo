﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmChangeRoom : Form
    {
        public FrmChangeRoom()
        {
            InitializeComponent();
        }

        int p = 0;

       
        public void SetText(RoomInfo room)
        {
            lblRoomId.Text = room.RoomId.ToString();
            txtRName.Text = room.RoomName;
            txtRType.Text = room.RoomType.ToString();
            txtRMinMoney.Text = room.RoomMinimunConsume.ToString();
            txtRPerNum.Text = room.RoomMaxConsumer.ToString();  
            txtIsDeflaut.Text = room.IsDefault.ToString();
            p = 1;
         
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            
            RoomInfo r = new RoomInfo();
            r.DelFlag = 0;
            r.IsDefault = Convert.ToInt32(txtIsDeflaut.Text);

            r.RoomMaxConsumer = Convert.ToDecimal(txtRPerNum.Text);
            r.RoomMinimunConsume = Convert.ToDecimal(txtRMinMoney.Text);
            r.RoomName = txtRName.Text;
            r.RoomType = Convert.ToInt32(txtRType.Text);
            r.SubBy = 1;
            r.SubTime = DateTime.Now;

            RoomInfoBLL bll = new RoomInfoBLL();
            string msg = "";
            if (p == 0)
            {
                msg = bll.AddRoom(r) ? "Complete" : "Fail";
            }
            else if(p == 1)
            {
                r.RoomId = Convert.ToInt32(lblRoomId.Text);
                msg = bll.UpdateRoomInfoByRoomId(r) ? "Complete":"Fail";   
             }
            MessageBox.Show(msg);
            this.Close();
        }
    }
}
