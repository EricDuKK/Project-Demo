﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;


namespace ItcastCater
{
    public partial class FrmUpdateMemberInfo : Form
    {
        //申明一个标识
        private int tp;

        public FrmUpdateMemberInfo()
        {
            InitializeComponent();
        }

        // 直接写个方法，不要Load方法
        private void LoadMemberTypeByDelFlag(int p)
        {
            MemberTypeBLL mtb = new MemberTypeBLL();
            List<MemberType> list = mtb.GetAllMemberTypeByDelFlag(p);
            list.Insert(0, new MemberType() { MemType = -1, MemTpName = "Select" });
            cmbMemType.DataSource = list;
            cmbMemType.DisplayMember = "MemTpName";
            cmbMemType.ValueMember = "MemType";
        }
        
        //为该窗体所有文本框赋值
        public void SetTex(MyEventArgs e)
        {
            LoadMemberTypeByDelFlag(0);
            MyEventArgs mea = e as MyEventArgs;
            tp = mea.Temp;
            if(tp == 1) //新增
            {
                //清空所有文本框
                foreach(Control item in this.Controls)
                {
                    if(item is TextBox)
                    {
                        TextBox tb = item as TextBox;
                        tb.Text = "";
                    }
                }
                txtMemIntegral.Text = "0";
                rdoMan.Checked = true;

            }
            if(tp == 2) //修改
            {
                MemberInfo memberInfo = mea.Obj as MemberInfo;
                txtBirs.Text = memberInfo.MemBirthdaty.ToString(); //生日
                txtMemDiscount.Text = memberInfo.MemDiscount.ToString();  //折扣
                txtMemIntegral.Text = memberInfo.MemIntegral.ToString();//积分
                txtmemMoney.Text = memberInfo.MemMoney.ToString();// 余下额度
                txtMemName.Text = memberInfo.MemName; // 名字
                txtMemNum.Text = memberInfo.MemNum;//编号
                txtMemPhone.Text = memberInfo.MemMobilePhone;//电话
                //性别
                rdoMan.Checked = memberInfo.MemGender == "男"? true:false;
                rdoWomen.Checked = memberInfo.MemGender == "女"?true:false;  
                //结束时间
                dtEndServerTime.Value = Convert.ToDateTime(memberInfo.MemEndServerTime);
                //id存起来
                labId.Text = memberInfo.MemmberId.ToString();

                //绑定会员等级
                cmbMemType.SelectedValue = memberInfo.MemType;

            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //判断新增或是修改
            if(CheckEmpty())
            {
                //获取每个文本框的值
                MemberInfo mem = new MemberInfo();
                // mem.MemAddress=地址不要了
                mem.MemBirthdaty = Convert.ToDateTime(txtBirs.Text);
                mem.MemDiscount = Convert.ToDecimal(txtMemDiscount.Text);
                mem.MemEndServerTime = Convert.ToDateTime(dtEndServerTime.Value);
                mem.MemGender = CheckGender();//性别
                mem.MemIntegral = Convert.ToInt32(txtMemIntegral.Text);
                mem.MemMobilePhone = txtMemPhone.Text;
                mem.MemMoney = Convert.ToDecimal(txtmemMoney.Text);
                mem.MemName = txtMemName.Text;
                mem.MemNum = txtMemNum.Text;
                mem.MemType = Convert.ToInt32(cmbMemType.SelectedValue);

                if (tp == 1)//新增
                {
                    mem.SubTime = System.DateTime.Now;
                    mem.DelFlag = 0;
                }
                if (tp == 2)//修改
                {
                    mem.MemmberId = Convert.ToInt32(labId.Text);
                }

                MemberInfoBLL infoBLL = new MemberInfoBLL();
                string msg = infoBLL.SaveMemberInfo(mem, tp) ? "Complete" : "Fail";
                MessageBox.Show(msg);
                this.Close();
            }
           
        }

        //判断性别
        private string CheckGender()
        {
            string gender = "";

            if(rdoMan.Checked)
            {
                gender = "男";
            }
            if(rdoWomen.Checked)
            {
                gender = "女";
            }
            return gender;
        }


        //判断所有的文本框均不为空
        private bool CheckEmpty()
        {
            if (string.IsNullOrEmpty(txtBirs.Text))
            {
                MessageBox.Show("Number can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtMemDiscount.Text))
            {
                MessageBox.Show("Discount can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtMemIntegral.Text))
            {
                MessageBox.Show("Credit can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtmemMoney.Text))
            {
                MessageBox.Show("Money can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtMemName.Text))
            {
                MessageBox.Show("Name can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtMemNum.Text))
            {
                MessageBox.Show("Number can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtMemPhone.Text))
            {
                MessageBox.Show("Phone number can't be empty");
                return false;
            }
            if (cmbMemType.SelectedIndex == 0)
            {
                MessageBox.Show("Type can't be empty");
                return false;
            }
            return true;
        }
    }
}
