﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmMemberInfo : Form
    {
        public FrmMemberInfo()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvMemmber.SelectedRows.Count > 0) //有选中的行
            {
                MemberInfoBLL memberInfoBLL = new MemberInfoBLL();
                int id = Convert.ToInt32(dgvMemmber.SelectedRows[0].Cells[0].Value);
                string msg = memberInfoBLL.DeleteMemberInfoByMemberId(id) ? "Complete" : "Fail";
                MessageBox.Show(msg);
                LoadMemberInfoByDelFlag(0); //刷新
            }
        }

        private void FrmMemberInfo_Load(object sender, EventArgs e)
        {
            LoadMemberInfoByDelFlag(0);
        }

        private void LoadMemberInfoByDelFlag(int p)
        {
            MemberInfoBLL memberInfoBLL = new MemberInfoBLL();
            dgvMemmber.AutoGenerateColumns = false;
            dgvMemmber.DataSource = memberInfoBLL.GetAllMemberInfoByDelFlag(p);
            dgvMemmber.SelectedRows[0].Selected = false;
        }

        public event EventHandler eventMember;
        MyEventArgs mea = new MyEventArgs();//用来传值的
       
        
        
        //标识1--新增 
        //增加会员
        private void btnAddMemMber_Click(object sender, EventArgs e)
        {
            mea.Temp = 1;
            ShowFrmUpdateMemberInfo();
        }

        //标识2--修改
        //修改会员
        private void btnUpdateMember_Click(object sender, EventArgs e)
        {   if(dgvMemmber.SelectedRows.Count>0)
            {
                //获取选中行的id
                //根据id去数据库查询
                int id = Convert.ToInt32(dgvMemmber.SelectedRows[0].Cells[0].Value.ToString());
                //去数据库查询数据
                MemberInfoBLL memberInfo = new MemberInfoBLL();
                mea.Obj = memberInfo.GetMemberInfoByMemberId(id);//得到了数据库对象
                mea.Temp = 2;

                ShowFrmUpdateMemberInfo();
            }
            else
            {
                MessageBox.Show("Please select");
            }
            
        }

        public void ShowFrmUpdateMemberInfo()
        {
             FrmUpdateMemberInfo frmUpdateMemberInfo = new FrmUpdateMemberInfo();
             frmUpdateMemberInfo.SetTex(mea);
             
             frmUpdateMemberInfo.FormClosed += FrmUpdateMemberInfo_FormClosed; //关闭刷新
             frmUpdateMemberInfo.ShowDialog();



        }

        private void FrmUpdateMemberInfo_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadMemberInfoByDelFlag(0);
        }

        

        private void txtNameAndNum_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNameAndNum.Text))
            {
                LoadMemberInfoByDelFlag(0);
                return;
            }
            MemberInfoBLL bll = new MemberInfoBLL();
            int n = 0;
            if (char.IsDigit(txtNameAndNum.Text[0]))
            {
                n = 2;
            }
            else
            {
                n = 1;
            }
            dgvMemmber.AutoGenerateColumns = false;
            dgvMemmber.DataSource = bll.GetMemmberInfoByNameOrNum(txtNameAndNum.Text, n);
            if (dgvMemmber.SelectedRows.Count > 0)
            {
                dgvMemmber.SelectedRows[0].Selected = false;
            }
        }
    }
}
