﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmAddAndChangeDesk : Form
    {
        public FrmAddAndChangeDesk()
        {
            InitializeComponent();
            LoadFrmAddAndChange();
        }

        private static FrmAddAndChangeDesk instance;

        public static FrmAddAndChangeDesk Instance
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                {
                    instance = new FrmAddAndChangeDesk();
                }
                return instance;
            }
        }
        private void LoadFrmAddAndChange()
        {
            RoomInfoBLL bll = new RoomInfoBLL();
            List<RoomInfo> roomList = bll.GetAllRoomInfoByDelFlag(0);
            cmbRoomId.DataSource = roomList;
            cmbRoomId.DisplayMember = "RoomName";
            cmbRoomId.ValueMember = "RoomId";

        }

        int p = 0;
        public void SetText(DeskInfo deskInfo)
        {
            
            DeskInfoBLL bll = new DeskInfoBLL();
            DeskInfo desk = bll.GetDeskInfoByDeskId(deskInfo.DeskId);
            txtDeskName.Text = desk.DeskName;
            txtDeskRegion.Text = desk.DeskRegion;
            txtDeskRemark.Text = desk.DeskRemark;
            rdoEmpty.Checked = desk.DeskState == 0;
            rdoOccupied.Checked = desk.DeskState == 1;
            cmbRoomId.SelectedValue= desk.RoomId;
            txtDeskId.Text = deskInfo.DeskId.ToString();
            p = 1;
        }

        private void btnDeskConfirm_Click(object sender, EventArgs e)
        {
            

            //int state = -1;

            //if (rdoEmpty.Checked)
            //{
            //    state = 0;
            //}
            //else if (rdoOccupied.Checked)
            //{
            //    state = 1;
            //}

            DeskInfo desk = new DeskInfo();
            desk.DeskName = txtDeskName.Text;
            desk.DeskRemark = txtDeskRemark.Text;
            desk.DeskRegion = txtDeskRegion.Text;
            //desk.DeskState = state;
            desk.DeskState = 0;
            desk.SubTime = DateTime.Now;
            desk.RoomId = Convert.ToInt32(cmbRoomId.SelectedValue);
            DeskInfoBLL bll = new DeskInfoBLL();

            string msg = "";
            if(p == 0)
            {
                msg = bll.InsertDeskInfoByDefault(desk) ? "Addition Complete" : "Addition Fail";
            }
            else
            {
                desk.DeskId = Convert.ToInt32(txtDeskId.Text);
                msg = bll.UpdateDeskInfoByDeskId(desk) ? "Modify Complete" : "Modify Fail";
            }
            
            MessageBox.Show(msg);

        }

       
    }
}
