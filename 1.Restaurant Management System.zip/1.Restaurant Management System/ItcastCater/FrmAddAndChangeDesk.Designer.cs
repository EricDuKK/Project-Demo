﻿namespace ItcastCater
{
    partial class FrmAddAndChangeDesk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtDeskName = new System.Windows.Forms.TextBox();
            this.txtDeskRegion = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDeskRemark = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnDeskConfirm = new System.Windows.Forms.Button();
            this.txtDeskId = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbRoomId = new System.Windows.Forms.ComboBox();
            this.rdoEmpty = new System.Windows.Forms.RadioButton();
            this.rdoOccupied = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Desk Number";
            // 
            // txtDeskName
            // 
            this.txtDeskName.Location = new System.Drawing.Point(132, 67);
            this.txtDeskName.Name = "txtDeskName";
            this.txtDeskName.Size = new System.Drawing.Size(100, 25);
            this.txtDeskName.TabIndex = 1;
            // 
            // txtDeskRegion
            // 
            this.txtDeskRegion.Location = new System.Drawing.Point(132, 113);
            this.txtDeskRegion.Name = "txtDeskRegion";
            this.txtDeskRegion.Size = new System.Drawing.Size(100, 25);
            this.txtDeskRegion.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Desk Desc";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Desk Status";
            this.label3.Visible = false;
            // 
            // txtDeskRemark
            // 
            this.txtDeskRemark.Location = new System.Drawing.Point(132, 158);
            this.txtDeskRemark.Name = "txtDeskRemark";
            this.txtDeskRemark.Size = new System.Drawing.Size(100, 25);
            this.txtDeskRemark.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Desk Remark";
            // 
            // btnDeskConfirm
            // 
            this.btnDeskConfirm.Location = new System.Drawing.Point(82, 321);
            this.btnDeskConfirm.Name = "btnDeskConfirm";
            this.btnDeskConfirm.Size = new System.Drawing.Size(81, 31);
            this.btnDeskConfirm.TabIndex = 8;
            this.btnDeskConfirm.Text = "Confirm";
            this.btnDeskConfirm.UseVisualStyleBackColor = true;
            this.btnDeskConfirm.Click += new System.EventHandler(this.btnDeskConfirm_Click);
            // 
            // txtDeskId
            // 
            this.txtDeskId.AutoSize = true;
            this.txtDeskId.Location = new System.Drawing.Point(208, 300);
            this.txtDeskId.Name = "txtDeskId";
            this.txtDeskId.Size = new System.Drawing.Size(0, 15);
            this.txtDeskId.TabIndex = 9;
            this.txtDeskId.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Room Type";
            // 
            // cmbRoomId
            // 
            this.cmbRoomId.FormattingEnabled = true;
            this.cmbRoomId.Location = new System.Drawing.Point(132, 209);
            this.cmbRoomId.Name = "cmbRoomId";
            this.cmbRoomId.Size = new System.Drawing.Size(101, 23);
            this.cmbRoomId.TabIndex = 14;
            // 
            // rdoEmpty
            // 
            this.rdoEmpty.AutoSize = true;
            this.rdoEmpty.Location = new System.Drawing.Point(131, 32);
            this.rdoEmpty.Name = "rdoEmpty";
            this.rdoEmpty.Size = new System.Drawing.Size(84, 19);
            this.rdoEmpty.TabIndex = 15;
            this.rdoEmpty.TabStop = true;
            this.rdoEmpty.Text = "vacancy";
            this.rdoEmpty.UseVisualStyleBackColor = true;
            this.rdoEmpty.Visible = false;
            // 
            // rdoOccupied
            // 
            this.rdoOccupied.AutoSize = true;
            this.rdoOccupied.Location = new System.Drawing.Point(221, 34);
            this.rdoOccupied.Name = "rdoOccupied";
            this.rdoOccupied.Size = new System.Drawing.Size(92, 19);
            this.rdoOccupied.TabIndex = 16;
            this.rdoOccupied.TabStop = true;
            this.rdoOccupied.Text = "occupied";
            this.rdoOccupied.UseVisualStyleBackColor = true;
            this.rdoOccupied.Visible = false;
            // 
            // FrmAddAndChangeDesk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 375);
            this.Controls.Add(this.rdoOccupied);
            this.Controls.Add(this.rdoEmpty);
            this.Controls.Add(this.cmbRoomId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtDeskId);
            this.Controls.Add(this.btnDeskConfirm);
            this.Controls.Add(this.txtDeskRemark);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDeskRegion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDeskName);
            this.Controls.Add(this.label1);
            this.Name = "FrmAddAndChangeDesk";
            this.Text = "FrmAddAndChangeDesk";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDeskName;
        private System.Windows.Forms.TextBox txtDeskRegion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDeskRemark;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDeskConfirm;
        private System.Windows.Forms.Label txtDeskId;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbRoomId;
        private System.Windows.Forms.RadioButton rdoEmpty;
        private System.Windows.Forms.RadioButton rdoOccupied;
    }
}