﻿namespace ItcastCater
{
    partial class FrmUpdateMemberInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtEndServerTime = new System.Windows.Forms.DateTimePicker();
            this.labId = new System.Windows.Forms.Label();
            this.cmbMemType = new System.Windows.Forms.ComboBox();
            this.rdoWomen = new System.Windows.Forms.RadioButton();
            this.rdoMan = new System.Windows.Forms.RadioButton();
            this.btnOk = new System.Windows.Forms.Button();
            this.txtMemDiscount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMemPhone = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBirs = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMemIntegral = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtmemMoney = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMemName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMemNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dtEndServerTime
            // 
            this.dtEndServerTime.Location = new System.Drawing.Point(470, 230);
            this.dtEndServerTime.Margin = new System.Windows.Forms.Padding(4);
            this.dtEndServerTime.Name = "dtEndServerTime";
            this.dtEndServerTime.Size = new System.Drawing.Size(209, 25);
            this.dtEndServerTime.TabIndex = 163;
            // 
            // labId
            // 
            this.labId.AutoSize = true;
            this.labId.Location = new System.Drawing.Point(613, 282);
            this.labId.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labId.Name = "labId";
            this.labId.Size = new System.Drawing.Size(0, 15);
            this.labId.TabIndex = 162;
            this.labId.Visible = false;
            // 
            // cmbMemType
            // 
            this.cmbMemType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMemType.FormattingEnabled = true;
            this.cmbMemType.Location = new System.Drawing.Point(130, 207);
            this.cmbMemType.Margin = new System.Windows.Forms.Padding(4);
            this.cmbMemType.Name = "cmbMemType";
            this.cmbMemType.Size = new System.Drawing.Size(201, 23);
            this.cmbMemType.TabIndex = 161;
            // 
            // rdoWomen
            // 
            this.rdoWomen.AutoSize = true;
            this.rdoWomen.Location = new System.Drawing.Point(212, 148);
            this.rdoWomen.Margin = new System.Windows.Forms.Padding(4);
            this.rdoWomen.Name = "rdoWomen";
            this.rdoWomen.Size = new System.Drawing.Size(76, 19);
            this.rdoWomen.TabIndex = 160;
            this.rdoWomen.TabStop = true;
            this.rdoWomen.Text = "Female";
            this.rdoWomen.UseVisualStyleBackColor = true;
            // 
            // rdoMan
            // 
            this.rdoMan.AutoSize = true;
            this.rdoMan.Location = new System.Drawing.Point(130, 148);
            this.rdoMan.Margin = new System.Windows.Forms.Padding(4);
            this.rdoMan.Name = "rdoMan";
            this.rdoMan.Size = new System.Drawing.Size(60, 19);
            this.rdoMan.TabIndex = 159;
            this.rdoMan.TabStop = true;
            this.rdoMan.Text = "Male";
            this.rdoMan.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(435, 275);
            this.btnOk.Margin = new System.Windows.Forms.Padding(4);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(100, 29);
            this.btnOk.TabIndex = 158;
            this.btnOk.Text = "Confirm";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // txtMemDiscount
            // 
            this.txtMemDiscount.Location = new System.Drawing.Point(470, 195);
            this.txtMemDiscount.Margin = new System.Windows.Forms.Padding(4);
            this.txtMemDiscount.Name = "txtMemDiscount";
            this.txtMemDiscount.Size = new System.Drawing.Size(201, 25);
            this.txtMemDiscount.TabIndex = 157;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(371, 199);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 15);
            this.label9.TabIndex = 156;
            this.label9.Text = "Discount:";
            // 
            // txtMemPhone
            // 
            this.txtMemPhone.Location = new System.Drawing.Point(470, 150);
            this.txtMemPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtMemPhone.Name = "txtMemPhone";
            this.txtMemPhone.Size = new System.Drawing.Size(201, 25);
            this.txtMemPhone.TabIndex = 155;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(371, 154);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 15);
            this.label8.TabIndex = 149;
            this.label8.Text = "Telephone:";
            // 
            // txtBirs
            // 
            this.txtBirs.Location = new System.Drawing.Point(470, 98);
            this.txtBirs.Margin = new System.Windows.Forms.Padding(4);
            this.txtBirs.Name = "txtBirs";
            this.txtBirs.Size = new System.Drawing.Size(201, 25);
            this.txtBirs.TabIndex = 151;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(371, 101);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 15);
            this.label7.TabIndex = 150;
            this.label7.Text = "Birthday:";
            // 
            // txtMemIntegral
            // 
            this.txtMemIntegral.Location = new System.Drawing.Point(470, 50);
            this.txtMemIntegral.Margin = new System.Windows.Forms.Padding(4);
            this.txtMemIntegral.Name = "txtMemIntegral";
            this.txtMemIntegral.Size = new System.Drawing.Size(201, 25);
            this.txtMemIntegral.TabIndex = 152;
            this.txtMemIntegral.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(371, 54);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 15);
            this.label6.TabIndex = 148;
            this.label6.Text = "Credit:";
            // 
            // txtmemMoney
            // 
            this.txtmemMoney.Location = new System.Drawing.Point(130, 249);
            this.txtmemMoney.Margin = new System.Windows.Forms.Padding(4);
            this.txtmemMoney.Name = "txtmemMoney";
            this.txtmemMoney.Size = new System.Drawing.Size(201, 25);
            this.txtmemMoney.TabIndex = 153;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 253);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 15);
            this.label5.TabIndex = 147;
            this.label5.Text = "Balance:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 207);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 15);
            this.label4.TabIndex = 146;
            this.label4.Text = "Level:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 153);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 15);
            this.label3.TabIndex = 145;
            this.label3.Text = "Gender:";
            // 
            // txtMemName
            // 
            this.txtMemName.Location = new System.Drawing.Point(130, 94);
            this.txtMemName.Margin = new System.Windows.Forms.Padding(4);
            this.txtMemName.Name = "txtMemName";
            this.txtMemName.Size = new System.Drawing.Size(201, 25);
            this.txtMemName.TabIndex = 154;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 98);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 144;
            this.label2.Text = "Name:";
            // 
            // txtMemNum
            // 
            this.txtMemNum.Location = new System.Drawing.Point(130, 47);
            this.txtMemNum.Margin = new System.Windows.Forms.Padding(4);
            this.txtMemNum.Name = "txtMemNum";
            this.txtMemNum.Size = new System.Drawing.Size(201, 25);
            this.txtMemNum.TabIndex = 143;
            this.txtMemNum.Text = "编号自动生成";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 15);
            this.label1.TabIndex = 142;
            this.label1.Text = "Number:";
            // 
            // FrmUpdateMemberInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Turquoise;
            this.ClientSize = new System.Drawing.Size(707, 345);
            this.Controls.Add(this.dtEndServerTime);
            this.Controls.Add(this.labId);
            this.Controls.Add(this.cmbMemType);
            this.Controls.Add(this.rdoWomen);
            this.Controls.Add(this.rdoMan);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.txtMemDiscount);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtMemPhone);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtBirs);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtMemIntegral);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtmemMoney);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMemName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMemNum);
            this.Controls.Add(this.label1);
            this.Name = "FrmUpdateMemberInfo";
            this.Text = "Add and Modify Membership  ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtEndServerTime;
        private System.Windows.Forms.Label labId;
        private System.Windows.Forms.ComboBox cmbMemType;
        private System.Windows.Forms.RadioButton rdoWomen;
        private System.Windows.Forms.RadioButton rdoMan;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.TextBox txtMemDiscount;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMemPhone;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBirs;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMemIntegral;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtmemMoney;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMemName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMemNum;
        private System.Windows.Forms.Label label1;
    }
}