﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmBilling : Form
    {
        public FrmBilling()
        {
            InitializeComponent();
        }

        private int ID { get; set; }
        public void SetText(object sender, EventArgs e)
        {
            MyEventArgs mea = e as MyEventArgs;
            DeskInfo dk = mea.Obj as DeskInfo;//获取餐桌对象
            labDeskName.Text = dk.DeskName;//餐桌的编号
            labRoomType.Text = mea.Name;//房间的类型
            labLittleMoney.Text = mea.Money.ToString();//最低消费

            //餐桌的id
            this.ID = dk.DeskId;

        }
        public event EventHandler evtFrmMoney;

        //确定开单
        private void btnOK_Click_1(object sender, EventArgs e)
        {
            //更改餐桌的状态
            DeskInfoBLL dkBll = new DeskInfoBLL();
            bool dkFlag = dkBll.UpdateDeskStateByDeskId(this.ID, 1);//
            //添加一个订单
            OrderInfoBLL orBll = new OrderInfoBLL();
            OrderInfo o = new OrderInfo();
            o.SubTime = System.DateTime.Now;//当前时间
            o.DelFlag = 0;
            o.OrderMoney = 0;//初次订单的钱0;
            o.OrderState = 1;//状态
            o.Remark = txtPersonCount.Text + txtDescription.Text;
            o.SubBy = 1;
            int orderId = orBll.AddOrderInfo(o);//.获取订单的id
            //添加中间表的数据
            R_Order_DeskBLL rodBll = new R_Order_DeskBLL();
            R_Order_Desk rod = new R_Order_Desk();
            rod.DeskId = this.ID;
            rod.OrderId = orderId;
            bool rodFlag = rodBll.AddROrderDesk(rod);
            if (dkFlag && rodFlag)
            {
                MessageBox.Show("Complete");
                //if (ckbMeal.Checked)
                //{
                    MyEventArgs mea = new MyEventArgs();
                    mea.Name = labDeskName.Text;//餐桌的编号
                    mea.Temp = orderId;//订单的id
                    //窗体传值
                    FrmAddMoney fam = new FrmAddMoney();
                    this.evtFrmMoney += new EventHandler(fam.SetText);
                    if (this.evtFrmMoney != null)
                    {
                        this.evtFrmMoney(this, mea);
                        fam.FormClosed += new FormClosedEventHandler(fam_FormClosed);
                        fam.ShowDialog();
                    }

               // }
            }
            else
            {
                MessageBox.Show("Fail");
            }
        }

        void fam_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        
    }
}
