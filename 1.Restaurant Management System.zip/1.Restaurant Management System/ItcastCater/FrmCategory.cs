﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmCategory : Form
    {
        public FrmCategory()
        {
            InitializeComponent();
        }

        //产品
        private void FrmCategory_Load(object sender, EventArgs e)
        {
            //加载所有的商品类别
            LoadCategoryInfoByDelFlag(0);

            //加载所有的产品
            LoadProductInfoByDelFlag(0);

            //显示所有类别
            LoadCategoryInfoByDelFlagToCmb(0);

        }

        //绑定下拉框
        private void LoadCategoryInfoByDelFlagToCmb(int p)
        {
            CategoryInfoBLL bll = new CategoryInfoBLL();
            List<CategoryInfo> list = bll.GetAllCategoryInfoByDelFlag(p);
            list.Insert(0, new CategoryInfo() { CatId = -1, CatName = "Select" });
            cmbCategory.DataSource = list;
            cmbCategory.DisplayMember = "CatName";
            cmbCategory.ValueMember = "CatId";
        }

        //类别
        private void LoadProductInfoByDelFlag(int v)
        {
            ProductInfoBLL bll = new ProductInfoBLL();
            dgvProductInfo.AutoGenerateColumns = false;
            dgvProductInfo.DataSource = bll.GetAllProductInfoByDelFlag(0);
            dgvProductInfo.SelectedRows[0].Selected = false;
        }

        private void LoadCategoryInfoByDelFlag(int p)
        {
            CategoryInfoBLL bll = new CategoryInfoBLL();
            dgvCategoryInfo.AutoGenerateColumns = false;
            dgvCategoryInfo.DataSource = bll.GetAllCategoryInfoByDelFlag(p);
            dgvCategoryInfo.SelectedRows[0].Selected = false;
        }

        //增加商品类别
        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            LoadFrmChangeCategoryInfo(1);
        }

        //修改商品类别
        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            if(dgvCategoryInfo.SelectedRows.Count > 0)
            {
                //选中行后获取id
                //根据id获得对象
                int id = Convert.ToInt32(dgvCategoryInfo.SelectedRows[0].Cells[0].Value.ToString());
                CategoryInfoBLL bll = new CategoryInfoBLL();
                CategoryInfo ct = bll.GetCategoryInfoById(id);
                 if(ct != null)
                {
                    mea.Obj = ct;
                    LoadFrmChangeCategoryInfo(2);
                }

                
            }
            else
            {
                MessageBox.Show("Please select");
            }
            
        }

        //p --1表示新增， --2表示修改
        //显示新增或者修改的商品类别窗体
        MyEventArgs mea = new MyEventArgs();
        public event EventHandler evtFcc;
        private void LoadFrmChangeCategoryInfo(int p)
        {
            FrmChangeCategory fcc = new FrmChangeCategory();
            this.evtFcc +=new EventHandler(fcc.SetText);
            mea.Temp = p;//标识存起来
            if(this.evtFcc != null)
            {
                this.evtFcc(this, mea);
                fcc.FormClosed += Fcc_FormClosed;
                fcc.ShowDialog();
            }

        }

        //刷新--是新增或修改窗体关闭后调用的方法
        private void Fcc_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadCategoryInfoByDelFlag(0);
        }

        //删除产品
        private void btnDeletePro_Click(object sender, EventArgs e)
        {
            if(dgvProductInfo.SelectedRows.Count > 0)//有选中的行
            {
                DialogResult result= MessageBox.Show("Are you sure", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (DialogResult.OK== result)
                {
                    int id = Convert.ToInt32(dgvProductInfo.SelectedRows[0].Cells[0].Value.ToString());
                    ProductInfoBLL bll = new ProductInfoBLL();
                    string msg = bll.SoftDeleteProductInfoByProId(id) ? "Complete" : "Fail";
                    MessageBox.Show(msg);
                    LoadProductInfoByDelFlag(0);

                }
                

            }
            else
            {
                MessageBox.Show("Please select");
            }
        }

        public event EventHandler evtFcp;

        //增加产品
        private void btnAddPro_Click(object sender, EventArgs e)
        {
            ShowFrmChangeProduct(3);
        }

        //修改产品
        private void btnUpdatePro_Click(object sender, EventArgs e)
        {
            if(dgvProductInfo.SelectedRows.Count>0)
            {
                //获取id
                int id = Convert.ToInt32(dgvProductInfo.SelectedRows[0].Cells[0].Value.ToString());

                ProductInfoBLL bll = new ProductInfoBLL();
                ProductInfo pro = bll.GetProductInfoById(id);
                if (pro != null)
                {
                    meaFcp.Obj = pro;
                    //获取id
                    ShowFrmChangeProduct(4);
                }

  
            }
            else
            {
                MessageBox.Show("Plese select");
            }


            
        }

        MyEventArgs meaFcp = new MyEventArgs();
        // 3---表示新增， 4---表示修改
        private void ShowFrmChangeProduct(int p)
        {
            FrmChangeProduct fcp = new FrmChangeProduct();
            this.evtFcp += new EventHandler(fcp.SetText);
            meaFcp.Temp = p;//标识存起来
            if(this.evtFcp != null)
            {
                this.evtFcp(this, meaFcp);
                fcp.FormClosed += Fcp_FormClosed;
                fcp.ShowDialog();
            }

        }
        //产品刷新
        private void Fcp_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadProductInfoByDelFlag(0);
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCategory.SelectedIndex != 0)
            {
                int id = Convert.ToInt32(cmbCategory.SelectedValue);
                ProductInfoBLL bll = new ProductInfoBLL();
                dgvProductInfo.AutoGenerateColumns = false;
                dgvProductInfo.DataSource = bll.GetProductInfoByCatId(id);
                if (dgvProductInfo.SelectedRows.Count > 0)
                {
                    dgvProductInfo.SelectedRows[0].Selected = false;
                }
            }
            else
            {
                LoadProductInfoByDelFlag(0);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //获取文本框的内容


            //传到bll层
            ProductInfoBLL bll = new ProductInfoBLL();
            dgvProductInfo.AutoGenerateColumns = false;
            dgvProductInfo.DataSource = bll.GetProductInfoByProNum(txtSearch.Text);
            if (dgvProductInfo.SelectedRows.Count > 0)
            {
                dgvProductInfo.SelectedRows[0].Selected = false;
            }
            //集合绑定到dgv控件上
        }

        private void benDeleteCategory_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == MessageBox.Show("Are you sure?", "Delete", MessageBoxButtons.OKCancel, MessageBoxIcon.Question))
            {
                int id = Convert.ToInt32(dgvCategoryInfo.SelectedRows[0].Cells[0].Value.ToString());
                ProductInfoBLL bll = new ProductInfoBLL();

                if (bll.GetProductInfoCountByCatId(id) > 0)
                {
                    MessageBox.Show("This category has product inside, You can't delete，Please contact software company");
                    return;
                }
                CategoryInfoBLL cbll = new CategoryInfoBLL();
                string msg = cbll.SoftDelelteCategoryInfoByCatId(id) ? "Complete" : "Fail";
                MessageBox.Show(msg);
                LoadCategoryInfoByDelFlag(0);
            }
        }
    }
}
