﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItcastCater
{
    public class MyEventArgs:EventArgs
    {
        public int Temp { get; set; }   

        public Object Obj { get; set; }

        public decimal Money { get; set; }

        public string Name { get; set; }
    }
}
