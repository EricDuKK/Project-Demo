﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnEsc_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        

        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            if(CheckText()) //账号和密码不能为空
            {
                string msg = "";
                //判断用户登录是否成功
                UserInfoBLL userInfoBLL = new UserInfoBLL();
                string pwd = Common.GetStringMd5(txtPwd.Text);
                if(userInfoBLL.IsLoginByLoginName(txtName.Text,pwd , out msg))
                {
                     msgDiv1.MsgDivShow(msg,1,Bind);
                }
                else
                {
                    msgDiv1.MsgDivShow(msg, 1);
                }
            }
        }

        public void Bind()
        {
            //设置当前的登录窗口值
            this.DialogResult = DialogResult.OK;
        }

        //该方法判断账号和密码不能为空
        private bool CheckText()
        {
            bool result = true;

            if(string.IsNullOrEmpty(txtName.Text))
            {
                result = false;
                msgDiv1.MsgDivShow("UserName can't be empty", 1);
            }
            if(string.IsNullOrEmpty(txtPwd.Text))
            {
                result = false;
                msgDiv1.MsgDivShow("PassWord can't be empty", 1);
            }
            return result;   
        }
    }
}
