﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.Model;
using ItcastCater.BLL;

namespace ItcastCater
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnMember_Click(object sender, EventArgs e)
        {
            FrmMemberInfo fm = new FrmMemberInfo();
            fm.ShowDialog();
        }

        //商品类别
        private void button5_Click(object sender, EventArgs e)
        {
             FrmCategory frmCategory = new FrmCategory();
            frmCategory.ShowDialog();
        }

        //窗体加载的时候
        private void FrmMain_Load(object sender, EventArgs e)
        {
            //加载房间
            LoadRoomInfoByDelFlag(0);

            //加载餐桌
            LoadDeskInfoByRoomIdAndByTabPageIndex(tabc.TabPages[0]);

            //加载其他餐桌
            tabc.SelectedIndexChanged += Tabc_SelectedIndexChanged;

            //加载当前页面
            LoadCurrentPage();
        }

        /// <summary>
        /// 当前主页面加载信息
        /// </summary>
        public void LoadCurrentPage()
        {
            lblTime.Text = DateTime.Now.ToString();
            
            TabPage tp = tabc.SelectedTab;
           
            
            if(tp != null)
            {
                ListView lv = tp.Controls[0] as ListView;
           
            lv.SelectedIndexChanged += Lv_SelectedIndexChanged;
            tabc.SelectedIndexChanged += Tabc_SelectedIndexChanged1;

            DeskInfoBLL desk =new DeskInfoBLL();
            double total = desk.GetTotalNumberOfDesk();
            double empty = desk.GetEmptyNumberDesk();

            txtTotalDesk.Text = total.ToString();
            txtEmptyDesk.Text = empty.ToString();

            double rate  = (total - empty)/total;
            
            txtRate.Text = string.Format("{0:P}", rate);
            }
           
        }

        /// <summary>
        /// 换页时触发事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Tabc_SelectedIndexChanged1(object sender, EventArgs e)
        {
                
                TabControl tabc = sender as TabControl;

                
                TabPage tp = tabc.SelectedTab;

                if (tp != null)
                {
                    ListView list = tp.Controls[0] as ListView;
                    list.SelectedIndexChanged += Lv_SelectedIndexChanged;
                }
                 
        }

        private void Lv_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListView list = sender as ListView;

            if (list.SelectedItems.Count > 0)
            {
                DeskInfo desk = list.SelectedItems[0].Tag as DeskInfo;

                
                RoomInfoBLL bll = new RoomInfoBLL();

                RoomInfo room = bll.GetRoomInfoByRoomID(desk.RoomId);

                OrderInfoBLL order = new OrderInfoBLL();

                int orderId = order.GetOrderIdByDeskId(desk.DeskId);

                decimal money = order.GetMoney(orderId);

                int state = Convert.ToInt32(desk.DeskState);


                LoadProduct(orderId);


                if (state == 1)
                {
                    DateTime dateTime = order.GetBeginTime(orderId);
                    txtBeginTime.Text = dateTime.ToString();
                }
                else
                {
                    txtBeginTime.Text = "Vacant";
                }
                                           
                txtCost.Text = money.ToString() + " yuan";
                ;

                labSelected.Text = room.RoomName + "-" + desk.DeskName + "# Desk";
                
                
            } 

        }
        /// <summary>
        /// 加载消费项目
        /// </summary>
        /// <param name="orderId"></param>
        public void LoadProduct(int orderId)
        {
            R_OrderInfo_ProductBLL bll = new R_OrderInfo_ProductBLL();
            dgvAllPro.AutoGenerateColumns = false;
            dgvAllPro.DataSource = bll.GetROrderInfoProduct(orderId);
            if (dgvAllPro.Rows.Count > 0)
            {
                dgvAllPro.SelectedRows[0].Selected = false;
            }

        }


        private void Tabc_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadDeskInfoByRoomIdAndByTabPageIndex(tabc.SelectedTab);
        }

        //加载餐桌的方法
        private void LoadDeskInfoByRoomIdAndByTabPageIndex(TabPage tp)
        {
            if(tp != null)
            {
                RoomInfo r = tp.Tag as RoomInfo;//获取房间的对象
                ListView lv = tp.Controls[0] as ListView;//获取lv对象
                lv.Clear(); //清空
                DeskInfoBLL bll = new DeskInfoBLL();
                //根据房间的id获取该房间下的餐桌
                List<DeskInfo> listDesk = bll.GetAllDeskInfoByRoomId(Convert.ToInt32(r.RoomId));
                for (int i = 0; i < listDesk.Count; i++)
                {
                    //添加餐桌
                    lv.Items.Add(listDesk[i].DeskName, Convert.ToInt32(listDesk[i].DeskState));
                    lv.Items[i].Tag = listDesk[i];//把餐桌的对象绑定到了每个控件的tag属性中
                }
            }
            LoadCurrentPage();
        }

     

        //加载所有房间
        private void LoadRoomInfoByDelFlag(int p)
        {
            RoomInfoBLL rbll = new RoomInfoBLL();
            //获取所有的房间
            List<RoomInfo> listRoom = rbll.GetAllRoomInfoByDelFlag(p);
            for (int i = listRoom.Count - 1; i >= 0; i--)
            {
                TabPage tp = new TabPage();//创建一个选项卡
                tp.Text = listRoom[i].RoomName;//显示房间的名字
                tp.Tag = listRoom[i];//房间对象存到了tag属性
                ListView lv = new ListView();
                //设置的内容特别的多
                lv.LargeImageList = imageList1;//绑定图片
                lv.View = View.LargeIcon;//图片显示的方式
                lv.Dock = DockStyle.Fill;//设置显示的方式:填充父容器中
                lv.MultiSelect = false;//不能多选
                lv.BackColor = Color.White;//背景颜色
                tp.Controls.Add(lv);//lv控件添加到tabpage控件中
                tabc.TabPages.Add(tp);//tabpage控件添加到tabcontrol中
            }
            LoadCurrentPage();
        }

        public event EventHandler evtFBI;
        //顾客开单
        private void btnBilling_Click(object sender, EventArgs e)
        {
            TabPage tp = tabc.SelectedTab;
            //tp.Tag//房间的对象
            ListView lv = tp.Controls[0] as ListView;

            if (lv.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Please select");
                return;
            }
            //餐桌的状态
            if ((lv.SelectedItems[0].Tag as DeskInfo).DeskState != 0)
            {
                MessageBox.Show("Please select vacant desk");
                return;
            }

            MyEventArgs mea = new MyEventArgs();
            mea.Obj = lv.SelectedItems[0].Tag; //餐桌对象
            //房间对象
            FrmBilling fbi = new FrmBilling();
            mea.Name = (tp.Tag as RoomInfo).RoomName;// 房间的类型
            mea.Money = Convert.ToDecimal((tp.Tag as RoomInfo).RoomMinimunConsume); //   房间的最低消费
            this.evtFBI += new EventHandler(fbi.SetText);//注册事件
            if (this.evtFBI != null)
            {
                this.evtFBI(this, mea);
                fbi.FormClosed += new FormClosedEventHandler(fbi_FormClosed);
                fbi.ShowDialog();
            }
        }

        //开单窗体关闭后刷新
        void fbi_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadDeskInfoByRoomIdAndByTabPageIndex(tabc.SelectedTab);
            LoadCurrentPage();
        }

        public event EventHandler evtFrmMoney;

        //增加消费
        private void btnMoney_Click(object sender, EventArgs e)
        { 
            TabPage tp = tabc.SelectedTab;
            //tp.Tag//房间的对象
            ListView lv = tp.Controls[0] as ListView;

            if (lv.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Please select");
                return;
            }
            //餐桌的状态
            if ((lv.SelectedItems[0].Tag as DeskInfo).DeskState != 1)
            {
                MessageBox.Show("Please select occupied desk");
                return;
            }
            //注册事件
            FrmAddMoney fam = new FrmAddMoney();

            this.evtFrmMoney += new EventHandler(fam.SetText);
            MyEventArgs mea = new MyEventArgs();
            mea.Name = (lv.SelectedItems[0].Tag as DeskInfo).DeskName;//餐桌编号
            OrderInfoBLL bll = new OrderInfoBLL();
            //订单的id
            mea.Temp = bll.GetOrderIdByDeskId((lv.SelectedItems[0].Tag as DeskInfo).DeskId);
            //mea.Temp=
            //窗体传值
            if (this.evtFrmMoney != null)
            {
                this.evtFrmMoney(this, mea);
                fam.FormClosed += new FormClosedEventHandler(fbi_FormClosed);
                
                LoadCurrentPage();
                fam.ShowDialog();
            }

        }
        public event EventHandler evtFBalance;

        private void Checkout_Click(object sender, EventArgs e)
        {
            TabPage tp = tabc.SelectedTab;
            //tp.Tag//房间的对象
            ListView lv = tp.Controls[0] as ListView;

            if (lv.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Please Select");
                return;
            }
            //餐桌的状态
            if ((lv.SelectedItems[0].Tag as DeskInfo).DeskState != 1)
            {
                MessageBox.Show("Please select occupied desk");
                return;
            }
            FrmBalance fb = new FrmBalance();
            this.evtFBalance += new EventHandler(fb.SetText);
            MyEventArgs meaFB = new MyEventArgs();
            meaFB.Obj = lv.SelectedItems[0].Tag;//餐桌的对象
            if (this.evtFBalance != null)
            {
                this.evtFBalance(this, meaFB);
                fb.FormClosed += new FormClosedEventHandler(fbi_FormClosed);
                fb.ShowDialog();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FrmRoom room = FrmRoom.Instance;
            room.FormClosed += Room_FormClosed;
            room.Show();
        }

        //房间窗体关闭
        private void Room_FormClosed(object sender, FormClosedEventArgs e)
        {
            tabc.TabPages.Clear();

            //加载房间
            LoadRoomInfoByDelFlag(0);

            //加载餐桌
            LoadDeskInfoByRoomIdAndByTabPageIndex(tabc.TabPages[0]);

            //加载其他餐桌
            tabc.SelectedIndexChanged += Tabc_SelectedIndexChanged;

            LoadCurrentPage();

            
        }

        
    }
}
