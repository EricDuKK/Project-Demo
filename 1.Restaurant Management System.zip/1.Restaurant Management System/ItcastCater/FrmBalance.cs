﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmBalance : Form
    {
        public FrmBalance()
        {
            InitializeComponent();
        }

        private int dkId { get; set; }
        public void SetText(object sender, EventArgs e)
        {
            //餐桌的编号
            MyEventArgs mea = e as MyEventArgs;
            DeskInfo dk = mea.Obj as DeskInfo;
            this.dkId = dk.DeskId;//餐桌的id
            labDeskName.Text = dk.DeskName;
            //根据餐桌的id查找该餐桌正在使用的订单的id
            OrderInfoBLL bll = new OrderInfoBLL();
            int orderId = bll.GetOrderIdByDeskId(dk.DeskId);
            labOrderId.Text = orderId.ToString();//订单的id（编号）
            //获取消费的总金额
            decimal money = bll.GetMoney(orderId);
            labMoney.Text = money.ToString();//消费金额
            lblMoney.Text = money.ToString();
            
        }

        //窗体加载
        private void FrmBalance_Load(object sender, EventArgs e)
        {
            //加载会员信息
            LoadMemmberInfoByDelFlag(0);

            //加载该订单都用了什么菜
            LoadProduct(Convert.ToInt32(labOrderId.Text));
        }
        private void LoadProduct(int p)
        {
            R_OrderInfo_ProductBLL bll = new R_OrderInfo_ProductBLL();
            dgvAllPro.AutoGenerateColumns = false;
            dgvAllPro.DataSource = bll.GetROrderInfoProduct(p);
            dgvAllPro.SelectedRows[0].Selected = false;
        }

        //加载所有的会员
        private void LoadMemmberInfoByDelFlag(int p)
        {
            MemberInfoBLL bll = new MemberInfoBLL();
            List<MemberInfo> list = bll.GetAllMemberInfoByDelFlag(p);
            list.Insert(0, new MemberInfo() { MemmberId = -1, MemName = "Select" });
            cmbMemmber.DataSource = list;
            cmbMemmber.DisplayMember = "MemName";
            cmbMemmber.ValueMember = "MemmberId";
        }

        private void cmbMemmber_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMemmber.SelectedIndex != 0)
            {
                MemberInfoBLL bll = new MemberInfoBLL();
                MemberInfo mem = cmbMemmber.SelectedItem as MemberInfo;
                labTp.Text = bll.GetMemmberTypeNameByMemmberId(mem.MemmberId);//会员的级别
                labyeMoney.Text = mem.MemMoney.ToString();//余额
                lblDis.Text = mem.MemDiscount.ToString();//折扣
                lblMoney.Text = (Convert.ToDecimal(labMoney.Text) * mem.MemDiscount / 10).ToString();
            }
            else
            {
                labTp.Text = "";
                labyeMoney.Text = "";
                lblDis.Text = "";
                lblMoney.Text = labMoney.Text;
            }
        }

        // 结账
        private void btnAccounts_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMoney.Text))
            {
                MessageBox.Show("No money, No Way.");
                return;
            }
            if (Convert.ToDecimal(txtMoney.Text) < Convert.ToDecimal(lblMoney.Text))
            {
                MessageBox.Show("Not Enough Money");
                return;
            }
            //餐桌状态改变
            DeskInfoBLL bll = new DeskInfoBLL();
            bool dkFlag = bll.UpdateDeskStateByDeskId(this.dkId, 0);
            OrderInfo order = new OrderInfo();
            if (cmbMemmber.SelectedIndex != 0)
            {
                MemberInfo mem = cmbMemmber.SelectedItem as MemberInfo;
                //order.OrderMemId = mem.MemmberId;//会员的id
                //order.DisCount = mem.MemDiscount;//折扣
                //会员的余额.
                decimal money = Convert.ToDecimal(mem.MemMoney) - Convert.ToDecimal(lblMoney.Text);
                //判断给你们了

                //更新会员卡内的钱
                MemberInfoBLL memBll = new MemberInfoBLL();
                bool memFlag = memBll.UpdateMoneyByMemId(mem.MemmberId, money);
            }
            //订单的状态改变,钱,会员的id，折扣
            order.EndTime = System.DateTime.Now;//结束时间
            order.OrderId = Convert.ToInt32(labOrderId.Text);
            order.OrderMoney = Convert.ToDecimal(lblMoney.Text);

            OrderInfoBLL obll = new OrderInfoBLL();
            bool oFlag = obll.UpdateOrderInfoMoney(order);
            if (dkFlag && oFlag)
            {
                MessageBox.Show("Billing Complete");
            }
            else
            {
                MessageBox.Show("Fail");
            }
        }

        private void txtMoney_TextChanged(object sender, EventArgs e)
        {
            if(txtMoney.Text != "")
            {
                Decimal change = Convert.ToDecimal(txtMoney.Text)-Convert.ToDecimal(lblMoney.Text);
                lblSpareMoney.Text = change.ToString();
            }
            
        }
    }
}
