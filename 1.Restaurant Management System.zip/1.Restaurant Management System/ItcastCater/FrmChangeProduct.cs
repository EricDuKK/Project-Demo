﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmChangeProduct : Form
    {
        public FrmChangeProduct()
        {
            InitializeComponent();
        }

        private int TP { get; set; }//标识
        private void LoadCategoryInfoByDelFag(int p)
        {
            CategoryInfoBLL bll = new CategoryInfoBLL();

            List<CategoryInfo> list = new List<CategoryInfo>();
            list = bll.GetAllCategoryInfoByDelFlag(p);
            list.Insert(0, new CategoryInfo() { CatName = "Select", CatId = -1 });
            cmbCategory.DataSource = list;
            cmbCategory.DisplayMember = "CatName";
            cmbCategory.ValueMember = "CatId";
        }
        public void SetText(object sender, EventArgs e)
        {
            LoadCategoryInfoByDelFag(0);
            MyEventArgs mea = e as MyEventArgs;
            this.TP = mea.Temp;//标识

            if (this.TP == 3)//新增
            {

            }
            else if (this.TP == 4) //xi==
            {
                ProductInfo pro = mea.Obj as ProductInfo;
                txtCost.Text = pro.ProCost.ToString();
                txtName.Text = pro.ProName;
                txtNum.Text = pro.ProNum;
                txtPrice.Text = pro.ProPrice.ToString();
                txtRemark.Text = pro.Remark;
                txtSpell.Text = pro.ProSpell;
                txtStock.Text = pro.ProStock.ToString();
                txtUnit.Text = pro.ProUnit;
                labId.Text = pro.ProId.ToString();//id存起来

                //类别
                cmbCategory.SelectedValue = pro.CatId;
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            //判断是新增还是修改
            if (CheckEmpty())
            {
                ProductInfo pro = new ProductInfo();
                pro.CatId = Convert.ToInt32(cmbCategory.SelectedValue);
                pro.ProCost = Convert.ToDecimal(txtCost.Text);
                pro.ProName = txtName.Text;
                pro.ProNum = txtNum.Text;
                pro.ProPrice = Convert.ToDecimal(txtPrice.Text);
                pro.ProSpell = txtSpell.Text;
                pro.ProStock = Convert.ToDecimal(txtStock.Text);
                pro.ProUnit = txtUnit.Text;
                pro.Remark = txtRemark.Text;

                if (this.TP == 3)//新增
                {
                    pro.DelFlag = 0;
                    pro.SubBy = 1;
                    pro.SubTime = DateTime.Now;
                }
                else if (this.TP == 4)//修改
                {
                    pro.ProId = Convert.ToInt32(labId.Text);
                }
                ProductInfoBLL bll = new ProductInfoBLL();
                string msg = bll.SaveProduct(pro, this.TP) ? "Complete" : "Fail";
                MessageBox.Show(msg);
                this.Close();
            }
        }
        //判断每个文本框不能为空
        private bool CheckEmpty()
        {
            if (string.IsNullOrEmpty(txtCost.Text))
            {
                MessageBox.Show("Cost can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtName.Text))
            {
                MessageBox.Show("Name can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtNum.Text))
            {
                MessageBox.Show("Number can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtPrice.Text))
            {
                MessageBox.Show("Price can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtRemark.Text))
            {
                MessageBox.Show("Remark can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtSpell.Text))
            {
                MessageBox.Show("Spell can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtStock.Text))
            {
                MessageBox.Show("Stock can't be empty");
                return false;
            }
            if (string.IsNullOrEmpty(txtUnit.Text))
            {
                MessageBox.Show("Unit can't be empty");
                return false;
            }
            if (cmbCategory.SelectedIndex == 0)
            {
                MessageBox.Show("Select Category");
                return false;
            }
            return true;
        }
    }
}
