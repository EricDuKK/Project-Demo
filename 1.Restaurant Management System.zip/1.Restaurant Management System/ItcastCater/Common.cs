﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ItcastCater
{
    public static class Common
    {
        public static string GetStringMd5(string v)
        {
            //字节数组
            byte[] buff = Encoding.UTF8.GetBytes(v);

            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] bts = md5.ComputeHash(buff);
            string str = "";
            for (int i = 0; i < bts.Length; i++)
            {
                str += bts[i].ToString("x2");  // 16进制MD5值
            }
            return str;
        }
    }
}
