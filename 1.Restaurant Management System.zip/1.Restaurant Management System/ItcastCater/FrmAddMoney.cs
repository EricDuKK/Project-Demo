﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmAddMoney : Form
    {
        public FrmAddMoney()
        {
            InitializeComponent();
        }

        public void SetText(object sender, EventArgs e)
        {
            MyEventArgs mea = e as MyEventArgs;
            labDeskName.Text = mea.Name;//餐桌的编号
            //坑====
            labOrderId.Text = mea.Temp.ToString();
        }

        private void FrmAddMoney_Load_1(object sender, EventArgs e)
        {
            //加载所有的产品
            LoadProductInfoByDelFlag(0);
            //加载节点树的产品
            LoadCategoryInfoByDelFlag(0);
            //显示所有的点菜
            LoadROrderInfoProductByOrderId(Convert.ToInt32(labOrderId.Text));

        }

        //显示点的什么菜
        /// <summary>
        /// 
        /// </summary>
        /// <param name="p">订单的id</param>
        private void LoadROrderInfoProductByOrderId(int p)
        {
            R_OrderInfo_ProductBLL bll = new R_OrderInfo_ProductBLL();
            dgvROrderProduct.AutoGenerateColumns = false;
            dgvROrderProduct.DataSource = bll.GetROrderInfoProduct(p);
            if (dgvROrderProduct.SelectedRows.Count > 0)
            {
                dgvROrderProduct.SelectedRows[0].Selected = false;
            }
            //没判断
            R_OrderInfo_Product rop = bll.GetMoneyAndCount(p);
            labSumMoney1.Text = rop.MONEY.ToString();
            labCount.Text = rop.CT.ToString();
        }

            //加载节点树
            private void LoadCategoryInfoByDelFlag(int p)
        {
            //先加载商品类别
            CategoryInfoBLL bll = new CategoryInfoBLL();
            List<CategoryInfo> list = bll.GetAllCategoryInfoByDelFlag(p);
            for (int i = 0; i < list.Count; i++)
            {
                TreeNode tn = tvCategory.Nodes.Add(list[i].CatName);
                // tn.Tag = list[i].CatId;//存类别id
                LoadProductInfoByCatId(list[i].CatId, tn.Nodes);
            }
        }

        private void LoadProductInfoByCatId(int p, TreeNodeCollection tnc)
        {
            ProductInfoBLL bll = new ProductInfoBLL();
            List<ProductInfo> list = bll.GetProductInfoByCatId(p);
            for (int i = 0; i < list.Count; i++)
            {
                tnc.Add(list[i].ProName + "====" + list[i].ProPrice + "元");
            }
        }
        //加载主菜单
        private void LoadProductInfoByDelFlag(int p)
        {
            
            ProductInfoBLL bll = new ProductInfoBLL();
            dgvProduct.AutoGenerateColumns = false;
            dgvProduct.DataSource = bll.GetAllProductInfoByDelFlag(p);
            dgvProduct.SelectedRows[0].Selected = false;
        }

        // 点菜了
        private void dgvProduct_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int proId = Convert.ToInt32(dgvProduct.SelectedRows[0].Cells[0].Value.ToString());
            R_OrderInfo_Product rop = new R_OrderInfo_Product();
            rop.OrderId = Convert.ToInt32(labOrderId.Text);//订单的id
            rop.ProId = proId;//产品的id
            //,,DelFlag,SubTime,State,UnitCount

            rop.DelFlag = 0;
            rop.SubTime = System.DateTime.Now;
            rop.State = 0;
            if (string.IsNullOrEmpty(txtCount.Text) || txtCount.Text == "0" || txtCount.Text == "1")
            {
                rop.UnitCount = 1;
            }
            else
            {
                rop.UnitCount = Convert.ToInt32(txtCount.Text);//有异常--坑,
            }
            R_OrderInfo_ProductBLL bll = new R_OrderInfo_ProductBLL();
            bll.AddROrderInfoProduct(rop);
            LoadROrderInfoProductByOrderId(Convert.ToInt32(rop.OrderId));//查询点的什么产品
        }

        //搜索
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //拼音搜索 编号
            //强制
            if (string.IsNullOrEmpty(txtSearch.Text))
            {
                LoadProductInfoByDelFlag(0);
                return;
            }
            int n = 0;
            if (char.IsLetter(txtSearch.Text[0]))//第一个字符是字母
            {
                n = 1;
            }
            else
            {
                //第一个字符串不是字母
                n = 2;
            }
            ProductInfoBLL bll = new ProductInfoBLL();
            dgvProduct.AutoGenerateColumns = false;
            dgvProduct.DataSource = bll.GetProductInfoBySpellOrNum(txtSearch.Text, n);
            if (dgvProduct.SelectedRows.Count > 0)
            {
                dgvProduct.SelectedRows[0].Selected = false;
            }
        }

        //退菜
        private void btnDeleteRorderPro_Click(object sender, EventArgs e)
        {
            if (dgvROrderProduct.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvROrderProduct.SelectedRows[0].Cells[0].Value);
                R_OrderInfo_ProductBLL bll = new R_OrderInfo_ProductBLL();
                string msg = bll.SoftDeleteROrderProName(id) ? "Cancel Complete" : "Cancel Fail";
                MessageBox.Show(msg);
                LoadROrderInfoProductByOrderId(Convert.ToInt32(labOrderId.Text));
            }
            else
            {
                MessageBox.Show("Please select");
            }
        }

        //算钱
        private void FrmAddMoney_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!string.IsNullOrEmpty(labSumMoney1.Text)&&labSumMoney1.Text != "0")
            {
                OrderInfoBLL bll = new OrderInfoBLL();
                string msg = bll.UpdateMoney(Convert.ToInt32(labOrderId.Text), Convert.ToDecimal(labSumMoney1.Text),DateTime.Now) ? "Complete" : "Fail";
                
                MessageBox.Show(msg);
            }
           
        }
    }
}
