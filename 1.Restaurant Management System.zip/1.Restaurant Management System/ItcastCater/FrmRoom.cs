﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ItcastCater.BLL;
using ItcastCater.Model;

namespace ItcastCater
{
    public partial class FrmRoom : Form
    {
        public FrmRoom()
        {
            InitializeComponent();
        }

        private static FrmRoom instance;

        public static FrmRoom Instance
        {
            get
            {
                if (instance == null || instance.IsDisposed)
                {
                    instance = new FrmRoom();
                }
                return instance;
            }
        }

        /// <summary>
        /// 房间管理页面出现加载所有房间信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmRoom_Load(object sender, EventArgs e)
        {
            LoadRoomByDelFlag(0);
            LoadGetAllDeskInfoByDefaultFlag(0);
        }

       /// <summary>
       /// 调用数据库加载所有房间信息
       /// </summary>
       /// <param name="p"></param>
        private void LoadRoomByDelFlag(int p)
        {
            RoomInfoBLL bll = new RoomInfoBLL();
            dgvRoomInfo.AutoGenerateColumns = false;
            dgvRoomInfo.DataSource = bll.GetAllRoomInfoByDelFlag(p);
            dgvRoomInfo.SelectedRows[0].Selected = false;
        }

        //添加房间
        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            FrmChangeRoom fcr = new FrmChangeRoom();
            fcr.FormClosed += new FormClosedEventHandler(fcr_FormClosed);
            fcr.Show();
        }

        //添加房间窗口关闭时重新加载数据库更新页面信息
        private void fcr_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadRoomByDelFlag(0);

        }

        /// <summary>
        /// 加载数据库获取所有餐桌信息
        /// </summary>
        /// <param name="p">餐桌删除标识</param>
        private void LoadGetAllDeskInfoByDefaultFlag(int p)
        {
            DeskInfoBLL desk = new DeskInfoBLL();
            dgvDeskInfo.AutoGenerateColumns = false;
            dgvDeskInfo.DataSource = desk.GetAllDeskInfoByDefaultFlag(p);
           
            //dgvDeskInfo.SelectedRows[0].Selected = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RoomInfo room = new RoomInfo();
            FrmChangeRoom fcr = new FrmChangeRoom();

            if(dgvRoomInfo.SelectedRows.Count>0)
            {
                room.RoomId = Convert.ToInt32(dgvRoomInfo.SelectedRows[0].Cells[0].Value);
                room.RoomName= dgvRoomInfo.SelectedRows[0].Cells[1].Value.ToString();
                room.RoomMinimunConsume = Convert.ToInt32(dgvRoomInfo.SelectedRows[0].Cells[2].Value);
                room.RoomMaxConsumer = Convert.ToInt32(dgvRoomInfo.SelectedRows[0].Cells[3].Value);
                room.IsDefault = Convert.ToInt32(dgvRoomInfo.SelectedRows[0].Cells[4].Value);
                room.RoomType = Convert.ToInt32(dgvRoomInfo.SelectedRows[0].Cells[5].Value);
                fcr.SetText(room);
                fcr.FormClosed += Fcr_FormClosed;
                fcr.ShowDialog();

            }
            else
            {
                MessageBox.Show("Please select");
            }
        }

        // 修改窗口关闭时，刷新页面
        private void Fcr_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadRoomByDelFlag(0);
        }

        private void btnDeleteRoom_Click(object sender, EventArgs e)
        {
            if (dgvRoomInfo.SelectedRows.Count > 0)
            {
                DeskInfoBLL desk = new DeskInfoBLL();
                RoomInfoBLL bll = new RoomInfoBLL();
                int roomId = Convert.ToInt32(dgvRoomInfo.SelectedRows[0].Cells[0].Value.ToString());

                if (desk.GetDeskNumberByRoomId(roomId))
                {
                    MessageBox.Show("Please delete desk in this room first");
                }
                else
                {
                    string msg = bll.SoftDeleteRoomInfoByRoomId(roomId) ? "Complete" : "Fail";
                    LoadRoomByDelFlag(0);
                    MessageBox.Show(msg);    
                }

            }
            else
            {
                MessageBox.Show("Please select");
            }
        }

     
        /// <summary>
        /// 房间管理添加餐桌
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddDesk_Click(object sender, EventArgs e)
        {
            FrmAddAndChangeDesk fcd = FrmAddAndChangeDesk.Instance;
            fcd.FormClosed += Fcd_FormClosed;
            fcd.Show();
        }

        /// <summary>
        /// 添加餐桌结束，刷新餐桌
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Fcd_FormClosed(object sender, FormClosedEventArgs e)
        {
            LoadGetAllDeskInfoByDefaultFlag(0); 
        }

        /// <summary>
        /// 修改餐桌
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //private void btnUpdateDesk_Click(object sender, EventArgs e)
        //{
        //    if(dgvDeskInfo.SelectedRows.Count > 0)
        //    {
        //        DeskInfo desk = new DeskInfo();
        //        desk.DeskId = Convert.ToInt32(dgvDeskInfo.SelectedRows[0].Cells[0].Value);         

        //        FrmAddAndChangeDesk fcd = FrmAddAndChangeDesk.Instance;
        //        fcd.SetText(desk);

        //        fcd.FormClosed += Fcd_FormClosed;
        //        fcd.Show();
        //    }
        //    else
        //    {
        //        MessageBox.Show("请选择");
        //    }
            
        //}

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeskInfoBLL bll = new DeskInfoBLL();

            if(dgvDeskInfo.SelectedRows.Count > 0)
            {
                int deskId = Convert.ToInt32(dgvDeskInfo.SelectedRows[0].Cells[0].Value.ToString());
                string msg = bll.SoftDeleteDeskInfo(deskId) ? "Complete" : "Fail";
                LoadGetAllDeskInfoByDefaultFlag(0);
                MessageBox.Show(msg);
            }
            else
            {
                MessageBox.Show("Please select");
            }
        }
    }
}
