﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItcastCater.Model
{
    public class UserInfo
    {
        //    UserId INTEGER       NOT NULL
        //                            PRIMARY KEY AUTOINCREMENT,
        //UserName NVARCHAR(32),
        //LoginUserName NVARCHAR(32) NOT NULL,
        //Pwd           NVARCHAR(32) NOT NULL,
        //LastLoginTime DATE,
        //LastLoginIP NVARCHAR(32),
        //DelFlag SMALLINT,
        //SubTime       DATE

        private int userId;
        private string userName;
        private string pwd;
        private string loginUserName;
        private DateTime lastLoginTime;
        private DateTime subTime;
        private string lastLoginIP;
        private int delFlag;

        public int UserId
        { get { return userId; } set { userId = value; } }

        public string UserName
            { get { return userName; } set { userName = value; } }

        public string Pwd
        { get { return pwd; } set { pwd = value; } }

        public string LoginUserName
        { get { return loginUserName; } set { loginUserName = value; } }

        public DateTime LastLoginTime
        { get { return lastLoginTime; } set { lastLoginTime = value; } }    

        public string LastLoginIP
        { get { return lastLoginIP; } set { lastLoginIP = value; } }    

        public int DelFlag
        { get { return delFlag; } set { delFlag = value; } }   
        
        public DateTime SubTime
        { get { return subTime; } set { subTime = value; } }
    }
}
